/*
 * code_generator.c - PHASE 4: CODE GENERATION
 *
 * Walks the checked syntax tree and writes the equivalent C program.
 * Bengali C has the same structure as C, so the translation is line by line:
 *
 *   পূর্ণসংখ্যা প্রধান()            int main()
 *   পূর্ণসংখ্যা ক = ৫, খ[১০];        int v_1 = 5, v_2[10];
 *   দশমিক গড়;                     float v_3;
 *   অক্ষর নাম[২০] = "রহিম";         char v_4[20] = "রহিম";
 *   দেখাও("%d\n", ক);              printf("%d\n", v_1);
 *   নাও("%d", &ক);                 scanf("%d", &v_1);
 *   যদি / নাহলে                    if / else
 *   যতক্ষণ / করো ... যতক্ষণ         while / do ... while
 *   গণনার জন্য                     for
 *   থামো / পরবর্তী / ফেরত           break / continue / return
 *   এবং / অথবা / না                && / || / !
 *
 * Variables are renamed v_1, v_2 ... because many C compilers do not accept
 * Bengali names. The Bengali names are kept in a comment beside each
 * declaration. Unique numbers also mean that an inner variable and an outer
 * variable with the same Bengali name can never be confused.
 *
 * Expressions are written with exactly the brackets the programmer used.
 * Bengali C has the same operator precedence as C, so C reads every
 * expression the same way our parser did.
 */
#include <stdio.h>
#include <string.h>
#include "code_generator.h"
#include "symbol_table.h"

static FILE *out;
static int depth;      /* current indentation level */

static void indent(void)
{
    int i;
    for (i = 0; i < depth; i++)
        fputs("    ", out);
}

/* ------------------------------------------------------------------ */
/*  Expressions                                                        */
/* ------------------------------------------------------------------ */

static void emit_expression(const Node *node);

/* In  - -ক  the two minus signs must not touch, or C would read "--". */
static int needs_space(const Node *node)
{
    const Node *inner = node->left;
    if (inner == NULL || inner->parens || inner->kind != NODE_UNARY)
        return 0;
    if (node->op == OP_MINUS)
        return inner->op == OP_MINUS || inner->op == OP_DEC;
    if (node->op == OP_PLUS)
        return inner->op == OP_PLUS || inner->op == OP_INC;
    if (node->op == OP_AMP)
        return inner->op == OP_AMP;
    return 0;
}

static void emit_expression(const Node *node)
{
    if (node == NULL)
        return;
    if (node->parens)
        fputs("(", out);

    switch (node->kind) {
    case NODE_INT:
    case NODE_FLOAT:
    case NODE_CHAR:
    case NODE_STRING:
        fputs(node->text, out);             /* the same spelling works in C */
        break;

    case NODE_VAR:
        fprintf(out, "v_%d", node->sym->id);
        break;

    case NODE_UNARY:
        fputs(op_text(node->op), out);
        if (needs_space(node))
            fputs(" ", out);
        emit_expression(node->left);
        break;

    case NODE_POSTFIX:
        emit_expression(node->left);
        fputs(op_text(node->op), out);
        break;

    case NODE_BINARY:
    case NODE_ASSIGN:
        emit_expression(node->left);
        if (node->op == COMMA)
            fputs(", ", out);
        else
            fprintf(out, " %s ", op_text(node->op));
        emit_expression(node->right);
        break;

    case NODE_INDEX:
        emit_expression(node->left);
        fputs("[", out);
        emit_expression(node->right);
        fputs("]", out);
        break;

    case NODE_CAST:
        fprintf(out, "(%s) ", c_base_name(node->type.base));
        emit_expression(node->left);
        break;

    case NODE_TERNARY:
        emit_expression(node->cond);
        fputs(" ? ", out);
        emit_expression(node->left);
        fputs(" : ", out);
        emit_expression(node->right);
        break;

    case NODE_INIT_LIST: {
        const Node *item;
        fputs("{", out);
        for (item = node->list; item != NULL; item = item->next) {
            emit_expression(item);
            if (item->next != NULL)
                fputs(", ", out);
        }
        fputs("}", out);
        break;
    }

    default:
        break;
    }

    if (node->parens)
        fputs(")", out);
}

/* ------------------------------------------------------------------ */
/*  Statements                                                         */
/* ------------------------------------------------------------------ */

static void emit_statement(const Node *node);

static void emit_items(const Node *first)
{
    const Node *n;
    depth++;
    for (n = first; n != NULL; n = n->next)
        emit_statement(n);
    depth--;
}

/* "int v_1 = 5, v_2[10]"  (without the ';') */
static void emit_declaration_text(const Node *decl)
{
    const Node *d;
    int i;

    fprintf(out, "%s ", c_base_name(decl->type.base));
    for (d = decl->list; d != NULL; d = d->next) {
        fprintf(out, "v_%d", d->sym->id);
        for (i = 0; i < d->type.ndims; i++) {
            if (d->type.dims[i] >= 0)
                fprintf(out, "[%d]", d->type.dims[i]);
            else
                fputs("[]", out);
        }
        if (d->value != NULL) {
            fputs(" = ", out);
            emit_expression(d->value);
        }
        if (d->next != NULL)
            fputs(", ", out);
    }
}

/* The body of যদি / যতক্ষণ / গণনার জন্য / করো.
   A { } block starts on the same line; a single statement goes on the
   next line, indented. Returns 1 if the line was left open after a '}'. */
static int emit_body(const Node *body)
{
    if (body != NULL && body->kind == NODE_BLOCK) {
        fputs(" {\n", out);
        emit_items(body->list);
        indent();
        fputs("}", out);
        return 1;
    }
    fputs("\n", out);
    depth++;
    if (body != NULL)
        emit_statement(body);
    depth--;
    return 0;
}

static void emit_if(const Node *node)
{
    int open_line;

    indent();
    for (;;) {
        fputs("if (", out);
        emit_expression(node->cond);
        fputs(")", out);
        open_line = emit_body(node->body);

        if (node->else_body == NULL)
            break;
        if (open_line) {
            fputs(" else", out);
        } else {
            indent();
            fputs("else", out);
        }
        if (node->else_body->kind == NODE_IF) {     /* নাহলে যদি -> else if */
            fputs(" ", out);
            node = node->else_body;
            continue;
        }
        open_line = emit_body(node->else_body);
        break;
    }
    if (open_line)
        fputs("\n", out);
}

static void emit_statement(const Node *node)
{
    const Node *item;

    if (node == NULL)
        return;

    switch (node->kind) {
    case NODE_DECL:
        indent();
        emit_declaration_text(node);
        fputs(";   /* ", out);
        for (item = node->list; item != NULL; item = item->next)
            fprintf(out, "v_%d = %s%s", item->sym->id, item->text, item->next != NULL ? ", " : "");
        fputs(" */\n", out);
        break;

    case NODE_EXPR_STMT:
        indent();
        emit_expression(node->left);
        fputs(";\n", out);
        break;

    case NODE_PRINT:
    case NODE_INPUT:
        indent();
        fputs(node->kind == NODE_PRINT ? "printf(" : "scanf(", out);
        fputs(node->value->text, out);
        for (item = node->list; item != NULL; item = item->next) {
            fputs(", ", out);
            emit_expression(item);
        }
        fputs(");\n", out);
        break;

    case NODE_IF:
        emit_if(node);
        break;

    case NODE_WHILE:
        indent();
        fputs("while (", out);
        emit_expression(node->cond);
        fputs(")", out);
        if (emit_body(node->body))
            fputs("\n", out);
        break;

    case NODE_DO:
        indent();
        fputs("do", out);
        if (emit_body(node->body)) {
            fputs(" while (", out);
        } else {
            indent();
            fputs("while (", out);
        }
        emit_expression(node->cond);
        fputs(");\n", out);
        break;

    case NODE_FOR:
        indent();
        fputs("for (", out);
        if (node->init != NULL && node->init->kind == NODE_DECL)
            emit_declaration_text(node->init);
        else
            emit_expression(node->init);
        fputs(node->cond != NULL ? "; " : ";", out);
        emit_expression(node->cond);
        fputs(node->update != NULL ? "; " : ";", out);
        emit_expression(node->update);
        fputs(")", out);
        if (emit_body(node->body))
            fputs("\n", out);
        break;

    case NODE_BREAK:
        indent();
        fputs("break;\n", out);
        break;

    case NODE_CONTINUE:
        indent();
        fputs("continue;\n", out);
        break;

    case NODE_RETURN:
        indent();
        fputs("return ", out);
        emit_expression(node->value);
        fputs(";\n", out);
        break;

    case NODE_BLOCK:
        indent();
        fputs("{\n", out);
        emit_items(node->list);
        indent();
        fputs("}\n", out);
        break;

    default:
        break;
    }
}

int generate_c(const Node *program, const char *output_file, const char *source_name)
{
    out = fopen(output_file, "w");
    if (out == NULL) {
        printf("Error: cannot create '%s'\n", output_file);
        return 1;
    }
    depth = 0;

    fprintf(out, "/* Generated by bnc, the Bengali C compiler, from %s */\n", source_name);
    fputs("#include <stdio.h>\n\n", out);
    fputs("int main()\n{\n", out);
    emit_items(program->body->list);
    fputs("}\n", out);

    fclose(out);
    return 0;
}
