/*
 * parser.c - PHASE 2: SYNTAX ANALYSIS (the parser)
 *
 * The parser checks that the tokens come in a legal order and builds the
 * syntax tree. It is a RECURSIVE-DESCENT parser: there is one C function for
 * each rule of the grammar below, and the functions call each other the same
 * way the rules mention each other.
 *
 * GRAMMAR (a subset of C)   x* = zero or more x,  [x] = optional,  | = or
 *
 *   program      -> পূর্ণসংখ্যা প্রধান "(" ")" block END_OF_FILE
 *   block        -> "{" item* "}"
 *   item         -> declaration | statement
 *   declaration  -> type declarator ( "," declarator )* ";"
 *   type         -> পূর্ণসংখ্যা | দশমিক | অক্ষর
 *   declarator   -> IDENTIFIER ( "[" [INT_NUMBER] "]" )* [ "=" initializer ]
 *   initializer  -> assignment | "{" initializer ( "," initializer )* [","] "}"
 *   statement    -> block
 *                 | [expression] ";"
 *                 | দেখাও "(" STRING_LITERAL ( "," assignment )* ")" ";"
 *                 | নাও   "(" STRING_LITERAL ( "," assignment )* ")" ";"
 *                 | যদি "(" expression ")" statement [ নাহলে statement ]
 *                 | যতক্ষণ "(" expression ")" statement
 *                 | করো statement যতক্ষণ "(" expression ")" ";"
 *                 | গণনার জন্য "(" ( declaration | [expression] ";" )
 *                               [expression] ";" [expression] ")" statement
 *                 | থামো ";" | পরবর্তী ";" | ফেরত expression ";"
 *
 *   expression   -> assignment ( "," assignment )*      (C's comma operator)
 *   assignment   -> conditional [ ("=" | "+=" | "-=" | "*=" | "/=" | "%=") assignment ]
 *   conditional  -> logical_or [ "?" expression ":" conditional ]
 *   logical_or   -> logical_and ( "||" logical_and )*        (|| or অথবা)
 *   logical_and  -> bit_or      ( "&&" bit_or )*             (&& or এবং)
 *   bit_or       -> bit_xor     ( "|" bit_xor )*
 *   bit_xor      -> bit_and     ( "^" bit_and )*
 *   bit_and      -> equality    ( "&" equality )*
 *   equality     -> relational  ( ("==" | "!=") relational )*
 *   relational   -> shift       ( ("<" | ">" | "<=" | ">=") shift )*
 *   shift        -> additive    ( ("<<" | ">>") additive )*
 *   additive     -> term        ( ("+" | "-") term )*
 *   term         -> cast        ( ("*" | "/" | "%") cast )*
 *   cast         -> "(" type ")" cast | unary
 *   unary        -> ("++" | "--") unary | ("-" | "+" | "!" | "~" | "&") cast | postfix
 *   postfix      -> primary ( "[" expression "]" | "++" | "--" )*
 *   primary      -> IDENTIFIER | INT_NUMBER | FLOAT_NUMBER | CHAR_LITERAL
 *                 | STRING_LITERAL | "(" expression ")"
 *
 * OPERATOR PRECEDENCE is exactly C's. It comes from the order of the
 * expression rules: a rule lower in the list binds tighter.
 *
 * LEFT RECURSION: a rule like  additive -> additive "+" term  would make
 * parse_additive() call itself forever, so each rule uses a loop instead:
 * additive -> term ( "+" term )*. Assignment is right-associative
 * (a = b = 0 means a = (b = 0)), so it calls itself on the right side.
 *
 * DANGLING ELSE: in  যদি (a) যদি (b) x; নাহলে y;  the নাহলে belongs to the
 * nearest যদি, exactly as in C. This happens naturally: the inner parse_if()
 * sees the নাহলে first and takes it.
 *
 * ERROR RECOVERY ("panic mode"): after the first error in a statement, we
 * stop reporting errors and skip ahead to the next ';' or the next keyword
 * that starts a statement. Then we carry on, so one run can report several
 * mistakes instead of stopping at the first.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.h"

static TokenList *tokens;     /* the token list from the lexer        */
static int pos;               /* index of the current token           */
static int errors;            /* number of syntax errors found        */
static int panic_mode;        /* 1 while skipping after an error      */

/* ------------------------------------------------------------------ */
/*  Moving through the token list                                      */
/* ------------------------------------------------------------------ */

static Token *current(void)  { return &tokens->items[pos]; }
static Token *previous(void) { return &tokens->items[pos > 0 ? pos - 1 : 0]; }

static TokenType peek_type(int ahead)
{
    int i = pos + ahead;
    return tokens->items[i < tokens->count ? i : tokens->count - 1].type;
}

static int check(TokenType type) { return current()->type == type; }

static Token *advance(void)
{
    Token *token = current();
    if (token->type != TOKEN_EOF)
        pos++;
    return token;
}

static int match(TokenType type)
{
    if (check(type)) {
        advance();
        return 1;
    }
    return 0;
}

static int is_type_token(TokenType type)
{
    return type == TYPE_INT || type == TYPE_FLOAT || type == TYPE_CHAR;
}

static BaseType base_of(TokenType type)
{
    switch (type) {
    case TYPE_INT:   return BT_INT;
    case TYPE_FLOAT: return BT_FLOAT;
    default:         return BT_CHAR;
    }
}

/* ------------------------------------------------------------------ */
/*  Error reporting                                                    */
/* ------------------------------------------------------------------ */

static void syntax_error(int line, const char *message)
{
    if (panic_mode)          /* already reported an error in this statement */
        return;
    panic_mode = 1;
    errors++;
    printf("Line %d: Syntax error: %s\n", line, message);
}

/* How a token type is named in error messages */
static const char *describe(TokenType type)
{
    switch (type) {
    case SEMICOLON:     return "';'";
    case COMMA:         return "','";
    case LPAREN:        return "'('";
    case RPAREN:        return "')'";
    case LBRACE:        return "'{'";
    case RBRACE:        return "'}'";
    case LBRACKET:      return "'['";
    case RBRACKET:      return "']'";
    case OP_COLON:      return "':'";
    case OP_ASSIGN:     return "'='";
    case IDENTIFIER:    return "a variable name";
    case KEYWORD_WHILE: return "'যতক্ষণ'";
    case KEYWORD_MAIN:  return "'প্রধান'";
    default:            return token_name(type);
    }
}

/* The current token must be of this type. If it is, take it and return it.
   If not, report  "expected X <where>, but found Y"  and return NULL. */
static Token *expect(TokenType type, const char *where)
{
    char message[600];

    if (check(type))
        return advance();

    if (check(TOKEN_EOF))
        snprintf(message, sizeof message, "expected %s %s, but the file ended",
                 describe(type), where);
    else
        snprintf(message, sizeof message, "expected %s %s, but found '%s'",
                 describe(type), where, current()->text);

    /* A missing ';' belongs to the line before the next token,
       so the error is reported at the line of the previous token. */
    syntax_error(previous()->line, message);
    return NULL;
}

/* Tokens that can only appear at the start of a statement or declaration */
static int starts_statement(TokenType type)
{
    switch (type) {
    case TYPE_INT: case TYPE_FLOAT: case TYPE_CHAR:
    case KEYWORD_PRINT: case KEYWORD_INPUT: case KEYWORD_IF: case KEYWORD_WHILE:
    case KEYWORD_FOR: case KEYWORD_DO: case KEYWORD_BREAK: case KEYWORD_CONTINUE:
    case KEYWORD_RETURN:
        return 1;
    default:
        return 0;
    }
}

/* Panic mode: skip tokens until a place where a new statement can start.
   'start' is the position where the broken statement began. */
static void synchronize(int start)
{
    panic_mode = 0;

    if (pos == start) {
        if (check(TOKEN_EOF))
            return;
        advance();      /* the statement used no tokens: skip the bad one */
    } else if (previous()->type == SEMICOLON || previous()->type == RBRACE) {
        return;         /* the broken statement already ended */
    }

    while (!check(TOKEN_EOF)) {
        if (check(SEMICOLON)) {
            advance();
            return;
        }
        if (check(RBRACE) || starts_statement(current()->type))
            return;
        advance();
    }
}

/* ------------------------------------------------------------------ */
/*  Expressions                                                        */
/* ------------------------------------------------------------------ */

static Node *parse_expression(void);
static Node *parse_assignment(void);
static Node *parse_cast(void);

static Node *make_binary(Token *op, Node *left, Node *right)
{
    Node *node = new_node(NODE_BINARY, op->line);
    node->op = op->type;
    node->left = left;
    node->right = right;
    return node;
}

/* Skips a ( ... ) group, used after an error such as a call to an unknown function */
static void skip_parentheses(void)
{
    int depth = 0;
    do {
        if (check(LPAREN)) depth++;
        if (check(RPAREN)) depth--;
        if (check(SEMICOLON) || check(TOKEN_EOF)) return;
        advance();
    } while (depth > 0);
}

/* primary -> IDENTIFIER | number | character | text | "(" expression ")" */
static Node *parse_primary(void)
{
    Token *token = current();
    Node *node = NULL;
    char message[600];

    switch (token->type) {
    case INT_NUMBER:     node = new_node(NODE_INT, token->line);    break;
    case FLOAT_NUMBER:   node = new_node(NODE_FLOAT, token->line);  break;
    case CHAR_LITERAL:   node = new_node(NODE_CHAR, token->line);   break;
    case STRING_LITERAL: node = new_node(NODE_STRING, token->line); break;
    case IDENTIFIER:     node = new_node(NODE_VAR, token->line);    break;

    case LPAREN:
        advance();
        node = parse_expression();
        expect(RPAREN, "to close '('");
        if (node != NULL)
            node->parens = 1;
        return node;

    default:
        if (token->type == TOKEN_EOF)
            snprintf(message, sizeof message,
                     "expected a value (a number, a variable or '('), but the file ended");
        else
            snprintf(message, sizeof message,
                     "expected a value (a number, a variable or '('), but found '%s'",
                     token->text);
        syntax_error(token->line, message);
        return NULL;
    }

    node->text = copy_string(token->text);
    advance();
    return node;
}

/* postfix -> primary ( "[" expression "]" | "++" | "--" )* */
static Node *parse_postfix(void)
{
    Node *node = parse_primary();
    char message[600];

    for (;;) {
        if (check(LBRACKET)) {
            Token *bracket = advance();
            Node *index = new_node(NODE_INDEX, bracket->line);
            index->left = node;
            index->right = parse_expression();
            expect(RBRACKET, "to close '['");
            node = index;
        } else if (check(OP_INC) || check(OP_DEC)) {
            Token *op = advance();
            Node *post = new_node(NODE_POSTFIX, op->line);
            post->op = op->type;
            post->left = node;
            node = post;
        } else if (check(LPAREN) && node != NULL && node->kind == NODE_VAR && !node->parens) {
            /* e.g.  দেখা("...");  -> a misspelled keyword, or a C function */
            snprintf(message, sizeof message,
                     "'%s' is not a function. Did you misspell দেখাও or নাও? "
                     "(other functions are not part of this language)", node->text);
            syntax_error(node->line, message);
            skip_parentheses();
            return node;
        } else {
            return node;
        }
    }
}

/* unary -> ("++" | "--") unary | ("-" | "+" | "!" | "~" | "&") cast | postfix */
static Node *parse_unary(void)
{
    if (check(OP_INC) || check(OP_DEC) || check(OP_MINUS) || check(OP_PLUS) ||
        check(OP_NOT) || check(OP_TILDE) || check(OP_AMP)) {
        Token *op = advance();
        Node *node = new_node(NODE_UNARY, op->line);
        node->op = op->type;
        if (op->type == OP_INC || op->type == OP_DEC)
            node->left = parse_unary();
        else
            node->left = parse_cast();
        return node;
    }
    return parse_postfix();
}

/* cast -> "(" type ")" cast | unary        e.g.  (দশমিক) মোট / ৩ */
static Node *parse_cast(void)
{
    if (check(LPAREN) && is_type_token(peek_type(1))) {
        Token *paren = advance();
        Token *type_token = advance();
        Node *node = new_node(NODE_CAST, paren->line);
        node->type = scalar_type(base_of(type_token->type));
        expect(RPAREN, "after the type name in a cast");
        node->left = parse_cast();
        return node;
    }
    return parse_unary();
}

/* One level of binary operators: operand ( op operand )*
   'ops' lists the operators of this level and ends with TOKEN_EOF. */
static Node *binary_level(Node *(*operand)(void), const TokenType *ops)
{
    Node *left = operand();
    for (;;) {
        const TokenType *op_type;
        int found = 0;
        for (op_type = ops; *op_type != TOKEN_EOF; op_type++)
            if (check(*op_type))
                found = 1;
        if (!found)
            return left;
        {
            Token *op = advance();
            Node *right = operand();
            left = make_binary(op, left, right);
        }
    }
}

static Node *parse_term(void)
{
    static const TokenType ops[] = { OP_MUL, OP_DIV, OP_MOD, TOKEN_EOF };
    return binary_level(parse_cast, ops);
}
static Node *parse_additive(void)
{
    static const TokenType ops[] = { OP_PLUS, OP_MINUS, TOKEN_EOF };
    return binary_level(parse_term, ops);
}
static Node *parse_shift(void)
{
    static const TokenType ops[] = { OP_SHL, OP_SHR, TOKEN_EOF };
    return binary_level(parse_additive, ops);
}
static Node *parse_relational(void)
{
    static const TokenType ops[] = { OP_LT, OP_GT, OP_LE, OP_GE, TOKEN_EOF };
    return binary_level(parse_shift, ops);
}
static Node *parse_equality(void)
{
    static const TokenType ops[] = { OP_EQ, OP_NE, TOKEN_EOF };
    return binary_level(parse_relational, ops);
}
static Node *parse_bit_and(void)
{
    static const TokenType ops[] = { OP_AMP, TOKEN_EOF };
    return binary_level(parse_equality, ops);
}
static Node *parse_bit_xor(void)
{
    static const TokenType ops[] = { OP_XOR, TOKEN_EOF };
    return binary_level(parse_bit_and, ops);
}
static Node *parse_bit_or(void)
{
    static const TokenType ops[] = { OP_BIT_OR, TOKEN_EOF };
    return binary_level(parse_bit_xor, ops);
}
static Node *parse_logical_and(void)
{
    static const TokenType ops[] = { OP_AND, TOKEN_EOF };
    return binary_level(parse_bit_or, ops);
}
static Node *parse_logical_or(void)
{
    static const TokenType ops[] = { OP_OR, TOKEN_EOF };
    return binary_level(parse_logical_and, ops);
}

/* conditional -> logical_or [ "?" expression ":" conditional ] */
static Node *parse_conditional(void)
{
    Node *cond = parse_logical_or();
    if (check(OP_QUESTION)) {
        Token *question = advance();
        Node *node = new_node(NODE_TERNARY, question->line);
        node->cond = cond;
        node->left = parse_expression();
        expect(OP_COLON, "in the ? : operator");
        node->right = parse_conditional();
        return node;
    }
    return cond;
}

static int is_assignment_op(TokenType type)
{
    return type == OP_ASSIGN || type == OP_PLUS_ASSIGN || type == OP_MINUS_ASSIGN ||
           type == OP_MUL_ASSIGN || type == OP_DIV_ASSIGN || type == OP_MOD_ASSIGN;
}

/* assignment -> conditional [ assign_op assignment ]   (right-associative) */
static Node *parse_assignment(void)
{
    Node *left = parse_conditional();
    if (is_assignment_op(current()->type)) {
        Token *op = advance();
        Node *node = new_node(NODE_ASSIGN, op->line);
        node->op = op->type;
        node->left = left;
        node->right = parse_assignment();
        return node;
    }
    return left;
}

/* expression -> assignment ( "," assignment )*
   The comma operator: a, b  works out a, then b; the value is b.
   Used in loops like  গণনার জন্য (i = ০, j = n - ১; i < j; i++, j--)  */
static Node *parse_expression(void)
{
    Node *left = parse_assignment();
    while (check(COMMA)) {
        Token *op = advance();
        Node *right = parse_assignment();
        left = make_binary(op, left, right);
    }
    return left;
}

/* ------------------------------------------------------------------ */
/*  Declarations                                                       */
/* ------------------------------------------------------------------ */

/* initializer list:  { ১, ২, ৩ }   or   { {১, ২}, {৩, ৪} } */
static Node *parse_init_list(void)
{
    Token *brace = advance();
    Node *list = new_node(NODE_INIT_LIST, brace->line);
    char message[200];

    if (!check(RBRACE)) {
        do {
            if (check(RBRACE))          /* a comma after the last value is allowed */
                break;
            append_node(&list->list, check(LBRACE) ? parse_init_list() : parse_assignment());
        } while (match(COMMA));
    }
    snprintf(message, sizeof message, "to close the list of values opened on line %d", brace->line);
    expect(RBRACE, message);
    return list;
}

/* declarator -> IDENTIFIER ( "[" [size] "]" )* [ "=" initializer ] */
static Node *parse_declarator(BaseType base, const char *after)
{
    char where[200];
    Token *name;
    Node *node;

    snprintf(where, sizeof where, "after '%s'", after);
    name = expect(IDENTIFIER, where);
    node = new_node(NODE_DECLARATOR, name != NULL ? name->line : current()->line);
    node->text = copy_string(name != NULL ? name->text : "?");
    node->type = scalar_type(base);

    while (check(LBRACKET)) {
        int size = -1;                       /* -1: size not written, as in a[] */
        advance();
        if (check(INT_NUMBER)) {
            Token *number = advance();
            size = (strlen(number->text) > 9) ? 1000000000 : atoi(number->text);
        } else if (!check(RBRACKET)) {
            syntax_error(current()->line, "the size of an array must be a whole number, like [১০]");
            parse_expression();
        }
        expect(RBRACKET, "after the array size");

        if (node->type.ndims == MAX_DIMS)
            syntax_error(previous()->line, "an array can have at most 4 dimensions");
        else
            node->type.dims[node->type.ndims++] = size;
    }

    if (match(OP_ASSIGN))
        node->value = check(LBRACE) ? parse_init_list() : parse_assignment();
    return node;
}

/* declaration -> type declarator ( "," declarator )* ";" */
static Node *parse_declaration(void)
{
    Token *type_token = advance();
    Node *decl = new_node(NODE_DECL, type_token->line);

    decl->type = scalar_type(base_of(type_token->type));
    append_node(&decl->list, parse_declarator(decl->type.base, type_token->text));
    while (match(COMMA))
        append_node(&decl->list, parse_declarator(decl->type.base, ","));
    expect(SEMICOLON, "at the end of the declaration");
    return decl;
}

/* ------------------------------------------------------------------ */
/*  Statements                                                         */
/* ------------------------------------------------------------------ */

static Node *parse_statement(void);
static Node *parse_item(void);

/* Parses items until '}' or the end of the file */
static void parse_items(Node *block)
{
    while (!check(RBRACE) && !check(TOKEN_EOF)) {
        int start = pos;
        append_node(&block->list, parse_item());
        if (panic_mode)
            synchronize(start);
    }
}

/* block -> "{" item* "}" */
static Node *parse_block(void)
{
    Token *brace = advance();
    Node *block = new_node(NODE_BLOCK, brace->line);
    char message[200];

    parse_items(block);
    snprintf(message, sizeof message, "to close the '{' opened on line %d", brace->line);
    expect(RBRACE, message);
    return block;
}

/* দেখাও("format", values...);   নাও("format", &variables...); */
static Node *parse_print_or_input(NodeKind kind, const char *keyword)
{
    Token *word = advance();
    Node *node = new_node(kind, word->line);
    char message[400];

    snprintf(message, sizeof message, "after %s", keyword);
    expect(LPAREN, message);

    if (check(STRING_LITERAL)) {
        Token *format = advance();
        node->value = new_node(NODE_STRING, format->line);
        node->value->text = copy_string(format->text);
    } else {
        snprintf(message, sizeof message,
                 "the first value of %s must be a format text in quotes, like %s(\"%%d\\n\", ক);",
                 keyword, keyword);
        syntax_error(current()->line, message);
        if (!check(RPAREN))
            parse_assignment();
    }

    while (match(COMMA))
        append_node(&node->list, parse_assignment());

    snprintf(message, sizeof message, "after the values of %s", keyword);
    expect(RPAREN, message);
    snprintf(message, sizeof message, "after %s(...)", keyword);
    expect(SEMICOLON, message);
    return node;
}

/* if -> যদি "(" expression ")" statement [ নাহলে statement ] */
static Node *parse_if(void)
{
    Token *word = advance();
    Node *node = new_node(NODE_IF, word->line);

    expect(LPAREN, "after যদি");
    node->cond = parse_expression();
    expect(RPAREN, "after the condition of যদি");
    node->body = parse_statement();
    if (match(KEYWORD_ELSE))
        node->else_body = parse_statement();
    return node;
}

/* while -> যতক্ষণ "(" expression ")" statement */
static Node *parse_while(void)
{
    Token *word = advance();
    Node *node = new_node(NODE_WHILE, word->line);

    expect(LPAREN, "after যতক্ষণ");
    node->cond = parse_expression();
    expect(RPAREN, "after the condition of যতক্ষণ");
    node->body = parse_statement();
    return node;
}

/* do-while -> করো statement যতক্ষণ "(" expression ")" ";" */
static Node *parse_do(void)
{
    Token *word = advance();
    Node *node = new_node(NODE_DO, word->line);

    node->body = parse_statement();
    expect(KEYWORD_WHILE, "after the body of করো  (করো { ... } যতক্ষণ (...);)");
    expect(LPAREN, "after যতক্ষণ");
    node->cond = parse_expression();
    expect(RPAREN, "after the condition of যতক্ষণ");
    expect(SEMICOLON, "after করো ... যতক্ষণ (...)");
    return node;
}

/* for -> গণনার জন্য "(" (declaration | [expression] ";") [expression] ";" [expression] ")" statement */
static Node *parse_for(void)
{
    Token *word = advance();
    Node *node = new_node(NODE_FOR, word->line);

    expect(LPAREN, "after গণনার জন্য");

    if (is_type_token(current()->type)) {
        node->init = parse_declaration();               /* includes the ';' */
    } else {
        if (!check(SEMICOLON))
            node->init = parse_expression();
        expect(SEMICOLON, "after the first part of গণনার জন্য");
    }

    if (!check(SEMICOLON))
        node->cond = parse_expression();
    expect(SEMICOLON, "after the condition of গণনার জন্য");

    if (!check(RPAREN))
        node->update = parse_expression();
    expect(RPAREN, "after the third part of গণনার জন্য");

    node->body = parse_statement();
    return node;
}

static Node *parse_statement(void)
{
    Token *token = current();
    Node *node;
    char message[600];

    switch (token->type) {
    case LBRACE:           return parse_block();
    case KEYWORD_IF:       return parse_if();
    case KEYWORD_WHILE:    return parse_while();
    case KEYWORD_DO:       return parse_do();
    case KEYWORD_FOR:      return parse_for();
    case KEYWORD_PRINT:    return parse_print_or_input(NODE_PRINT, "দেখাও");
    case KEYWORD_INPUT:    return parse_print_or_input(NODE_INPUT, "নাও");

    case KEYWORD_BREAK:
    case KEYWORD_CONTINUE:
        advance();
        node = new_node(token->type == KEYWORD_BREAK ? NODE_BREAK : NODE_CONTINUE, token->line);
        snprintf(message, sizeof message, "after %s", token->text);
        expect(SEMICOLON, message);
        return node;

    case KEYWORD_RETURN:
        advance();
        node = new_node(NODE_RETURN, token->line);
        if (check(SEMICOLON))
            syntax_error(token->line, "ফেরত needs a value here, because প্রধান() returns a পূর্ণসংখ্যা: ফেরত ০;");
        else
            node->value = parse_expression();
        expect(SEMICOLON, "after ফেরত ...");
        return node;

    case SEMICOLON:                                     /* empty statement: ; */
        advance();
        return new_node(NODE_EXPR_STMT, token->line);

    case KEYWORD_ELSE:
        syntax_error(token->line, "নাহলে must come right after the statement of a যদি");
        advance();
        parse_statement();                              /* skip its statement */
        return NULL;

    case TYPE_INT: case TYPE_FLOAT: case TYPE_CHAR:
        /* e.g.  যদি (ক) পূর্ণসংখ্যা খ = ১;   - not allowed in C either */
        syntax_error(token->line, "a declaration cannot be used here; put it inside { }");
        parse_declaration();
        return NULL;

    case KEYWORD_MAIN:
        syntax_error(token->line, "প্রধান() can appear only once, at the start of the program");
        advance();
        return NULL;

    case RBRACE:
        syntax_error(token->line, "expected a statement before '}'");
        return NULL;

    case TOKEN_EOF:
        syntax_error(previous()->line, "expected a statement, but the file ended");
        return NULL;

    default:                                            /* expression ; */
        node = new_node(NODE_EXPR_STMT, token->line);
        node->left = parse_expression();
        expect(SEMICOLON, "at the end of the statement");
        return node;
    }
}

/* item -> declaration | statement */
static Node *parse_item(void)
{
    if (is_type_token(current()->type))
        return parse_declaration();
    return parse_statement();
}

/* The rest of the main header after the type:  প্রধান "(" ")" block */
static Node *parse_main(void)
{
    advance();                                          /* প্রধান */
    expect(LPAREN, "after প্রধান");
    expect(RPAREN, "after প্রধান(");
    if (check(LBRACE))
        return parse_block();

    expect(LBRACE, "after প্রধান()");
    panic_mode = 0;
    {
        Node *block = new_node(NODE_BLOCK, current()->line);
        parse_items(block);
        return block;
    }
}

/* program -> পূর্ণসংখ্যা প্রধান "(" ")" block END_OF_FILE */
Node *parse(TokenList *token_list, int *error_count)
{
    Node *program = new_node(NODE_PROGRAM, 1);

    tokens = token_list;
    pos = 0;
    errors = 0;
    panic_mode = 0;

    if (check(TYPE_INT) && peek_type(1) == KEYWORD_MAIN) {
        advance();
        program->body = parse_main();
    } else if (check(KEYWORD_MAIN)) {
        syntax_error(current()->line, "write পূর্ণসংখ্যা before প্রধান(), as in C: int main()");
        panic_mode = 0;
        program->body = parse_main();
    } else {
        syntax_error(current()->line, "the program must start with  পূর্ণসংখ্যা প্রধান()  "
                                      "and all the code goes inside its { }");
        panic_mode = 0;
        program->body = new_node(NODE_BLOCK, current()->line);
        parse_items(program->body);
    }

    panic_mode = 0;
    if (!check(TOKEN_EOF)) {
        char message[600];
        snprintf(message, sizeof message,
                 "found '%s' after the '}' that closes প্রধান(); all code must be inside প্রধান()",
                 current()->text);
        syntax_error(current()->line, message);
    }

    *error_count = errors;
    return program;
}
