/*
 * code_generator.h - PHASE 4: CODE GENERATION
 */
#ifndef CODE_GENERATOR_H
#define CODE_GENERATOR_H

#include "ast.h"

/* Writes the C translation of the program to output_file.
   Returns 0 on success, 1 if the file could not be written. */
int generate_c(const Node *program, const char *output_file, const char *source_name);

#endif
