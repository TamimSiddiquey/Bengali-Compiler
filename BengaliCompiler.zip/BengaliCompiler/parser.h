/*
 * parser.h - PHASE 2: SYNTAX ANALYSIS
 */
#ifndef PARSER_H
#define PARSER_H

#include "tokens.h"
#include "ast.h"

/* Builds the syntax tree from the token list.
   *error_count is set to the number of syntax errors found. */
Node *parse(TokenList *tokens, int *error_count);

#endif
