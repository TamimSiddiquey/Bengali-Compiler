/*
 * main.c - the compiler driver: runs every phase in order
 *
 *   project.bn  (a Bengali C program)
 *      |  [1] lexical analysis   (project.l)       -> list of tokens
 *      |  [2] syntax analysis    (parser.c)        -> syntax tree
 *      |  [3] semantic analysis  (semantic.c)      -> checked tree + symbol table
 *      |      intermediate code  (tac.c, --tac)    -> three-address code (display)
 *      |  [4] code generation    (code_generator.c)-> output.c
 *      |  [5] gcc -std=c99 output.c                -> program.exe
 *      v
 *   program.exe runs
 *
 * Usage:   bnc <file.bn> [options]
 *   --tokens    show the token list
 *   --ast       show the syntax tree
 *   --symbols   show the symbol table
 *   --tac       show the three-address code
 *   --all       show all four of the above
 *   --no-run    compile, but do not run the program
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tokens.h"
#include "ast.h"
#include "parser.h"
#include "symbol_table.h"
#include "semantic.h"
#include "tac.h"
#include "code_generator.h"

#define OUTPUT_C "output.c"

#ifdef _WIN32
#define PROGRAM_EXE "program.exe"
#define RUN_PROGRAM "program.exe"
#else
#define PROGRAM_EXE "program"
#define RUN_PROGRAM "./program"
#endif

static void print_usage(void)
{
    printf("Usage: bnc <file.bn> [options]\n");
    printf("  --tokens    show the token list (lexical analysis)\n");
    printf("  --ast       show the syntax tree (syntax analysis)\n");
    printf("  --symbols   show the symbol table (semantic analysis)\n");
    printf("  --tac       show the three-address code (intermediate code)\n");
    printf("  --all       show all of the above\n");
    printf("  --no-run    compile, but do not run the program\n");
}

static void heading(const char *title)
{
    printf("\n========== %s ==========\n", title);
}

/* Prints a line like:  [1] Lexical analysis ...... OK (42 tokens) */
static void phase_result(int number, const char *name, int errors, const char *details)
{
    int i;
    printf("[%d] %s ", number, name);
    for (i = (int) strlen(name); i < 20; i++)
        putchar('.');
    if (errors == 0)
        printf(" OK %s\n", details);
    else
        printf(" FAILED (%d error%s)\n", errors, errors == 1 ? "" : "s");
}

static int stop(int errors)
{
    printf("\nCompilation failed with %d error%s. No C code was generated.\n",
           errors, errors == 1 ? "" : "s");
    return 1;
}

int main(int argc, char *argv[])
{
    const char *source = NULL;
    int show_tokens = 0, show_ast = 0, show_symbols = 0, show_tac = 0, run = 1;
    int lex_errors, syntax_errors, semantic_errors, i;
    char details[100];
    TokenList tokens;
    Node *program;
    FILE *file;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--tokens") == 0)       show_tokens = 1;
        else if (strcmp(argv[i], "--ast") == 0)     show_ast = 1;
        else if (strcmp(argv[i], "--symbols") == 0) show_symbols = 1;
        else if (strcmp(argv[i], "--tac") == 0)     show_tac = 1;
        else if (strcmp(argv[i], "--all") == 0)     show_tokens = show_ast = show_symbols = show_tac = 1;
        else if (strcmp(argv[i], "--no-run") == 0)  run = 0;
        else if (argv[i][0] == '-') {
            printf("Unknown option '%s'\n\n", argv[i]);
            print_usage();
            return 1;
        }
        else source = argv[i];
    }
    if (source == NULL) {
        print_usage();
        return 1;
    }

#ifdef _WIN32
    system("chcp 65001 > nul");     /* let the console show Bengali (UTF-8) text */
#endif

    file = fopen(source, "r");
    if (file == NULL) {
        printf("Error: cannot open file '%s'\n", source);
        return 1;
    }
    printf("Compiling %s\n\n", source);

    /* ---- Phase 1: lexical analysis ---------------------------------- */
    lex_errors = tokenize(file, &tokens);
    fclose(file);
    if (show_tokens) {
        heading("TOKENS");
        print_tokens(&tokens);
        printf("\n");
    }
    sprintf(details, "(%d tokens)", tokens.count - 1);
    phase_result(1, "Lexical analysis", lex_errors, details);

    /* ---- Phase 2: syntax analysis ----------------------------------- */
    program = parse(&tokens, &syntax_errors);
    phase_result(2, "Syntax analysis", syntax_errors, "(syntax tree built)");
    if (lex_errors + syntax_errors > 0)
        return stop(lex_errors + syntax_errors);
    if (show_ast) {
        heading("SYNTAX TREE");
        ast_print(program, 0);
        printf("\n");
    }

    /* ---- Phase 3: semantic analysis --------------------------------- */
    semantic_errors = semantic_check(program);
    if (show_symbols) {
        heading("SYMBOL TABLE");
        st_print();
        printf("\n");
    }
    sprintf(details, "(%d variable%s, %d warning%s)",
            st_total(), st_total() == 1 ? "" : "s",
            semantic_warning_count(), semantic_warning_count() == 1 ? "" : "s");
    phase_result(3, "Semantic analysis", semantic_errors, details);
    if (semantic_errors > 0)
        return stop(semantic_errors);

    /* ---- Intermediate code (for display) ---------------------------- */
    if (show_tac) {
        heading("THREE-ADDRESS CODE");
        tac_print(program);
        printf("\n");
    }

    /* ---- Phase 4: code generation ----------------------------------- */
    if (generate_c(program, OUTPUT_C, source) != 0)
        return 1;
    phase_result(4, "Code generation", 0, "-> " OUTPUT_C);

    /* ---- Phase 5: compile the C code with gcc ----------------------- */
    fflush(stdout);         /* make sure our text appears before gcc's */
    if (system("gcc -std=c99 " OUTPUT_C " -o " PROGRAM_EXE) != 0) {
        phase_result(5, "GCC compilation", 1, "");
        printf("\ngcc could not compile " OUTPUT_C ".\n"
               "If the message above says 'gcc' is not recognized, gcc is not in your PATH.\n"
               "Otherwise the Bengali program was correct, so this is a bug in bnc:\n"
               "look at " OUTPUT_C " and the gcc message above.\n");
        return 1;
    }
    phase_result(5, "GCC compilation", 0, "-> " PROGRAM_EXE);

    /* ---- Run the program ------------------------------------------- */
    if (run) {
        heading("PROGRAM OUTPUT");
        fflush(stdout);
        system(RUN_PROGRAM);
        printf("========== END ==========\n");
    }
    return 0;
}
