/*
 * ast.c - creating and printing syntax tree nodes
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

Node *new_node(NodeKind kind, int line)
{
    Node *node = (Node *) calloc(1, sizeof(Node));   /* calloc sets every field to 0 / NULL */
    if (node == NULL) {
        printf("Out of memory\n");
        exit(1);
    }
    node->kind = kind;
    node->line = line;
    return node;
}

void append_node(Node **list, Node *item)
{
    if (item == NULL)
        return;
    while (*list != NULL)
        list = &(*list)->next;
    *list = item;
}

char *copy_string(const char *text)
{
    char *copy = (char *) malloc(strlen(text) + 1);
    if (copy == NULL) {
        printf("Out of memory\n");
        exit(1);
    }
    strcpy(copy, text);
    return copy;
}

Type scalar_type(BaseType base)
{
    Type type;
    memset(&type, 0, sizeof type);
    type.base = base;
    return type;
}

const char *base_name(BaseType base)
{
    switch (base) {
    case BT_INT:   return "পূর্ণসংখ্যা";
    case BT_FLOAT: return "দশমিক";
    case BT_CHAR:  return "অক্ষর";
    default:       return "?";
    }
}

const char *c_base_name(BaseType base)
{
    switch (base) {
    case BT_INT:   return "int";
    case BT_FLOAT: return "float";
    case BT_CHAR:  return "char";
    default:       return "?";
    }
}

/* Writes a type as text: "পূর্ণসংখ্যা", "অক্ষর[20]", "পূর্ণসংখ্যা[3][4]" */
void describe_type(Type type, char *buffer)
{
    int i;
    strcpy(buffer, base_name(type.base));
    for (i = 0; i < type.ndims; i++) {
        char part[24];
        if (type.dims[i] >= 0)
            sprintf(part, "[%d]", type.dims[i]);
        else
            strcpy(part, "[]");
        strcat(buffer, part);
    }
}

const char *op_text(TokenType op)
{
    switch (op) {
    case OP_PLUS:         return "+";
    case OP_MINUS:        return "-";
    case OP_MUL:          return "*";
    case OP_DIV:          return "/";
    case OP_MOD:          return "%";
    case OP_INC:          return "++";
    case OP_DEC:          return "--";
    case OP_ASSIGN:       return "=";
    case OP_PLUS_ASSIGN:  return "+=";
    case OP_MINUS_ASSIGN: return "-=";
    case OP_MUL_ASSIGN:   return "*=";
    case OP_DIV_ASSIGN:   return "/=";
    case OP_MOD_ASSIGN:   return "%=";
    case OP_EQ:           return "==";
    case OP_NE:           return "!=";
    case OP_LT:           return "<";
    case OP_GT:           return ">";
    case OP_LE:           return "<=";
    case OP_GE:           return ">=";
    case OP_AND:          return "&&";
    case OP_OR:           return "||";
    case OP_NOT:          return "!";
    case OP_AMP:          return "&";
    case OP_BIT_OR:       return "|";
    case OP_XOR:          return "^";
    case OP_TILDE:        return "~";
    case OP_SHL:          return "<<";
    case OP_SHR:          return ">>";
    case COMMA:           return ",";
    default:              return "?";
    }
}

/* ------------------------------------------------------------------ */
/*  Printing the tree (used by:  bnc file.bn --ast)                    */
/* ------------------------------------------------------------------ */

static void indent(int depth)
{
    int i;
    for (i = 0; i < depth; i++)
        printf("|   ");
}

static void print_list(const Node *first, int depth)
{
    const Node *n;
    for (n = first; n != NULL; n = n->next)
        ast_print(n, depth);
}

static void print_labelled(const char *label, const Node *node, int depth)
{
    if (node == NULL)
        return;
    indent(depth);
    printf("%s\n", label);
    ast_print(node, depth + 1);
}

void ast_print(const Node *node, int depth)
{
    char type_text[100];

    if (node == NULL)
        return;

    indent(depth);
    switch (node->kind) {
    case NODE_PROGRAM:
        printf("PROGRAM  পূর্ণসংখ্যা প্রধান()\n");
        ast_print(node->body, depth + 1);
        break;
    case NODE_BLOCK:
        printf("BLOCK\n");
        print_list(node->list, depth + 1);
        break;
    case NODE_DECL:
        printf("DECLARE %s  (line %d)\n", base_name(node->type.base), node->line);
        print_list(node->list, depth + 1);
        break;
    case NODE_DECLARATOR:
        describe_type(node->type, type_text);
        printf("VARIABLE %s  : %s\n", node->text, type_text);
        print_labelled("INITIAL VALUE", node->value, depth + 1);
        break;
    case NODE_EXPR_STMT:
        printf("EXPRESSION  (line %d)\n", node->line);
        ast_print(node->left, depth + 1);
        break;
    case NODE_PRINT:
        printf("PRINT (printf)  (line %d)\n", node->line);
        ast_print(node->value, depth + 1);
        print_list(node->list, depth + 1);
        break;
    case NODE_INPUT:
        printf("INPUT (scanf)  (line %d)\n", node->line);
        ast_print(node->value, depth + 1);
        print_list(node->list, depth + 1);
        break;
    case NODE_IF:
        printf("IF  (line %d)\n", node->line);
        print_labelled("CONDITION", node->cond, depth + 1);
        print_labelled("THEN", node->body, depth + 1);
        print_labelled("ELSE", node->else_body, depth + 1);
        break;
    case NODE_WHILE:
        printf("WHILE  (line %d)\n", node->line);
        print_labelled("CONDITION", node->cond, depth + 1);
        print_labelled("BODY", node->body, depth + 1);
        break;
    case NODE_DO:
        printf("DO-WHILE  (line %d)\n", node->line);
        print_labelled("BODY", node->body, depth + 1);
        print_labelled("CONDITION", node->cond, depth + 1);
        break;
    case NODE_FOR:
        printf("FOR  (line %d)\n", node->line);
        print_labelled("START", node->init, depth + 1);
        print_labelled("CONDITION", node->cond, depth + 1);
        print_labelled("STEP", node->update, depth + 1);
        print_labelled("BODY", node->body, depth + 1);
        break;
    case NODE_BREAK:
        printf("BREAK  (line %d)\n", node->line);
        break;
    case NODE_CONTINUE:
        printf("CONTINUE  (line %d)\n", node->line);
        break;
    case NODE_RETURN:
        printf("RETURN  (line %d)\n", node->line);
        ast_print(node->value, depth + 1);
        break;
    case NODE_INT:
        printf("INT %s\n", node->text);
        break;
    case NODE_FLOAT:
        printf("FLOAT %s\n", node->text);
        break;
    case NODE_CHAR:
        printf("CHAR %s\n", node->text);
        break;
    case NODE_STRING:
        printf("STRING %s\n", node->text);
        break;
    case NODE_VAR:
        printf("VARIABLE %s\n", node->text);
        break;
    case NODE_BINARY:
        printf("BINARY %s\n", op_text(node->op));
        ast_print(node->left, depth + 1);
        ast_print(node->right, depth + 1);
        break;
    case NODE_UNARY:
        printf("UNARY %s\n", op_text(node->op));
        ast_print(node->left, depth + 1);
        break;
    case NODE_POSTFIX:
        printf("POSTFIX %s\n", op_text(node->op));
        ast_print(node->left, depth + 1);
        break;
    case NODE_ASSIGN:
        printf("ASSIGN %s\n", op_text(node->op));
        ast_print(node->left, depth + 1);
        ast_print(node->right, depth + 1);
        break;
    case NODE_INDEX:
        printf("INDEX [ ]\n");
        ast_print(node->left, depth + 1);
        ast_print(node->right, depth + 1);
        break;
    case NODE_CAST:
        printf("CAST (%s)\n", base_name(node->type.base));
        ast_print(node->left, depth + 1);
        break;
    case NODE_TERNARY:
        printf("CONDITIONAL ? :\n");
        ast_print(node->cond, depth + 1);
        ast_print(node->left, depth + 1);
        ast_print(node->right, depth + 1);
        break;
    case NODE_INIT_LIST:
        printf("LIST { }\n");
        print_list(node->list, depth + 1);
        break;
    }
}
