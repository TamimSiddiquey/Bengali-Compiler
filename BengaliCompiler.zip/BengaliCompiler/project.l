%option noyywrap
%option yylineno

BN_LETTER   \xE0\xA6[\x80-\xBF]|\xE0\xA7[\x80-\xA5]
BN_DIGIT    \xE0\xA7[\xA6-\xAF]
EN_LETTER   [A-Za-z_]
EN_DIGIT    [0-9]
DIGIT       {EN_DIGIT}|{BN_DIGIT}
EXPONENT    [eE][+-]?({DIGIT})+
ID_START    {BN_LETTER}|{EN_LETTER}
ID_CHAR     {BN_LETTER}|{BN_DIGIT}|{EN_LETTER}|{EN_DIGIT}
UTF8_CHAR   [\xC2-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF][\x80-\xBF]|[\xF0-\xF4][\x80-\xBF][\x80-\xBF][\x80-\xBF]

%x COMMENT

%{
/*
 * project.l - PHASE 1: LEXICAL ANALYSIS (the lexer)
 *
 * Flex turns this file into lex.yy.c, which contains yylex().
 * Every call to yylex() reads the next token from the source file and
 * returns its type (a number from tokens.h). tokenize(), at the bottom of
 * this file, calls yylex() again and again and stores every token in a list.
 *
 * Bengali text is stored in UTF-8, where every Bengali character takes
 * 3 bytes: E0, then A6 or A7, then one more byte. Flex only knows bytes,
 * so the named patterns above describe Bengali characters as byte sequences:
 *
 *   BN_LETTER  Bengali letters, vowel signs, hasanta... (U+0980 - U+09E5)
 *   BN_DIGIT   Bengali digits ০-৯                       (U+09E6 - U+09EF)
 *   UTF8_CHAR  any other UTF-8 character (2, 3 or 4 bytes), used to give
 *              a clear error for characters the language does not use
 *
 * How Flex picks a rule when several match:
 *   1. the LONGEST match wins          (নাম is an IDENTIFIER, not না + ম)
 *   2. on a tie, the EARLIER rule wins (যদি is a keyword, not an identifier)
 * That is why the keyword rules are written above the identifier rule.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "tokens.h"

static int   lex_error_count = 0;
static int   comment_line    = 0;    /* line where an open comment started */
static char *token_text      = NULL; /* text of the token just matched     */

static int  make_token(TokenType type);
static int  make_number(TokenType type);
static int  make_identifier(void);
static int  make_quoted(TokenType type);
static void lex_error(int line, const char *format, ...);
%}

%%

\xEF\xBB\xBF          { /* skip the BOM that some editors put at the start of a file */ }

"//".*                { /* one-line comment: ignore it */ }

"/*"                  { comment_line = yylineno; BEGIN(COMMENT); }
<COMMENT>"*/"         { BEGIN(INITIAL); }
<COMMENT>(.|\n)       { /* ignore everything inside a comment */ }
<COMMENT><<EOF>>      { lex_error(comment_line, "this comment is never closed with */");
                        BEGIN(INITIAL);
                        return TOKEN_EOF; }

"পূর্ণসংখ্যা"           { return make_token(TYPE_INT); }
"দশমিক"               { return make_token(TYPE_FLOAT); }
"অক্ষর"                { return make_token(TYPE_CHAR); }

"প্রধান"               { return make_token(KEYWORD_MAIN); }
"ফেরত"                { return make_token(KEYWORD_RETURN); }
"যদি"                 { return make_token(KEYWORD_IF); }
"নাহলে"               { return make_token(KEYWORD_ELSE); }
"যতক্ষণ"               { return make_token(KEYWORD_WHILE); }
"গণনার"[ \t]+"জন্য"    { return make_token(KEYWORD_FOR); }
"করো"                 { return make_token(KEYWORD_DO); }
"থামো"                { return make_token(KEYWORD_BREAK); }
"পরবর্তী"              { return make_token(KEYWORD_CONTINUE); }
"দেখাও"               { return make_token(KEYWORD_PRINT); }
"নাও"                 { return make_token(KEYWORD_INPUT); }

"এবং"                 { return make_token(OP_AND); }
"অথবা"                { return make_token(OP_OR); }
"না"                  { return make_token(OP_NOT); }

{ID_START}{ID_CHAR}*  { return make_identifier(); }

{DIGIT}+"."({DIGIT})*({EXPONENT})?  { return make_number(FLOAT_NUMBER); }
"."({DIGIT})+({EXPONENT})?          { return make_number(FLOAT_NUMBER); }
{DIGIT}+{EXPONENT}                  { return make_number(FLOAT_NUMBER); }
{DIGIT}+                            { return make_number(INT_NUMBER); }

\"([^"\\\n]|\\.)*\"   { return make_quoted(STRING_LITERAL); }
\"([^"\\\n]|\\.)*     { lex_error(yylineno, "the text %s has no closing \" on this line", yytext);
                        return make_token(STRING_LITERAL); }

'([^'\\\n]|\\.)'      { return make_quoted(CHAR_LITERAL); }
'[^'\n]*'?            { lex_error(yylineno, "%s is not a valid অক্ষর value: use exactly one English character, like 'a'", yytext);
                        return make_token(CHAR_LITERAL); }

"++"                  { return make_token(OP_INC); }
"--"                  { return make_token(OP_DEC); }
"+="                  { return make_token(OP_PLUS_ASSIGN); }
"-="                  { return make_token(OP_MINUS_ASSIGN); }
"*="                  { return make_token(OP_MUL_ASSIGN); }
"/="                  { return make_token(OP_DIV_ASSIGN); }
"%="                  { return make_token(OP_MOD_ASSIGN); }
"=="                  { return make_token(OP_EQ); }
"!="                  { return make_token(OP_NE); }
"<="                  { return make_token(OP_LE); }
">="                  { return make_token(OP_GE); }
"&&"                  { return make_token(OP_AND); }
"||"                  { return make_token(OP_OR); }
"<<"                  { return make_token(OP_SHL); }
">>"                  { return make_token(OP_SHR); }
"<"                   { return make_token(OP_LT); }
">"                   { return make_token(OP_GT); }
"!"                   { return make_token(OP_NOT); }
"="                   { return make_token(OP_ASSIGN); }
"+"                   { return make_token(OP_PLUS); }
"-"                   { return make_token(OP_MINUS); }
"*"                   { return make_token(OP_MUL); }
"/"                   { return make_token(OP_DIV); }
"%"                   { return make_token(OP_MOD); }
"&"                   { return make_token(OP_AMP); }
"|"                   { return make_token(OP_BIT_OR); }
"^"                   { return make_token(OP_XOR); }
"~"                   { return make_token(OP_TILDE); }
"?"                   { return make_token(OP_QUESTION); }
":"                   { return make_token(OP_COLON); }

";"                   { return make_token(SEMICOLON); }
","                   { return make_token(COMMA); }
"("                   { return make_token(LPAREN); }
")"                   { return make_token(RPAREN); }
"{"                   { return make_token(LBRACE); }
"}"                   { return make_token(RBRACE); }
"["                   { return make_token(LBRACKET); }
"]"                   { return make_token(RBRACKET); }

[ \t\r\n]+            { /* skip spaces, tabs and newlines */ }

{UTF8_CHAR}           { lex_error(yylineno, "unknown character '%s' (it is not part of the language)", yytext); }

.                     { if ((unsigned char) yytext[0] < 0x80)
                            lex_error(yylineno, "unknown symbol '%s' (it is not part of the language)", yytext);
                        else
                            lex_error(yylineno, "invalid byte 0x%02X: is the file saved as UTF-8?",
                                      (unsigned char) yytext[0]); }

%%

/* ------------------------------------------------------------------ */
/*  Helper functions used by the rules above                           */
/* ------------------------------------------------------------------ */

static char *copy_text(const char *text, int length)
{
    char *copy = (char *) malloc(length + 1);
    if (copy == NULL) {
        printf("Out of memory\n");
        exit(1);
    }
    memcpy(copy, text, length);
    copy[length] = '\0';
    return copy;
}

static void lex_error(int line, const char *format, ...)
{
    va_list args;
    printf("Line %d: Lexical error: ", line);
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
    printf("\n");
    lex_error_count++;
}

/* Most tokens: just remember the text that was matched. */
static int make_token(TokenType type)
{
    token_text = copy_text(yytext, yyleng);
    return type;
}

/* Numbers: convert Bengali digits to English ones ("২৫" -> "25", "৩.১৪" -> "3.14").
   Every byte E0 in a number is the start of a 3-byte Bengali digit E0 A7 xx,
   where xx goes from A6 (০) to AF (৯). Other bytes (0-9 . e E + -) are copied. */
static int make_number(TokenType type)
{
    int i = 0, j = 0;
    token_text = copy_text(yytext, yyleng);   /* the result is never longer */

    while (yytext[i] != '\0') {
        if ((unsigned char) yytext[i] == 0xE0) {
            token_text[j++] = (char) ('0' + ((unsigned char) yytext[i + 2] - 0xA6));
            i += 3;
        } else {
            token_text[j++] = yytext[i];
            i += 1;
        }
    }
    token_text[j] = '\0';
    return type;
}

/* Identifiers: য়, ড় and ঢ় can be typed in two different ways:
     one character   য় = E0 A7 9F
     two characters  য + nukta (়) = E0 A6 AF  E0 A6 BC
   They look identical on screen, so we turn the second form into the
   first. Otherwise "বয়স" typed on two keyboards could be two different
   variables. */
static int make_identifier(void)
{
    unsigned char *in, *out;
    token_text = copy_text(yytext, yyleng);
    in = out = (unsigned char *) token_text;

    while (*in != '\0') {
        if (in[0] == 0xE0 && in[1] == 0xA6 &&
            (in[2] == 0xAF || in[2] == 0xA1 || in[2] == 0xA2) &&
            in[3] == 0xE0 && in[4] == 0xA6 && in[5] == 0xBC) {
            out[0] = 0xE0;
            out[1] = 0xA7;
            out[2] = (in[2] == 0xAF) ? 0x9F : (in[2] == 0xA1) ? 0x9C : 0x9D;
            out += 3;
            in  += 6;
        } else {
            *out++ = *in++;
        }
    }
    *out = '\0';
    return IDENTIFIER;
}

/* Text "..." and characters '...': they are copied into the C program
   exactly as written, so only escape sequences that C knows are allowed. */
static int make_quoted(TokenType type)
{
    int i;
    for (i = 1; i < yyleng - 1; i++) {
        if (yytext[i] == '\\') {
            char next = yytext[i + 1];
            if (strchr("ntr0\\\"'abfv?", next) == NULL)
                lex_error(yylineno, "unknown escape '\\%c' (allowed: \\n \\t \\r \\0 \\\\ \\\" \\' \\a \\b \\f \\v \\?)", next);
            i++;   /* skip the escaped character */
        }
    }
    return make_token(type);
}

/* ------------------------------------------------------------------ */
/*  Functions used by main.c (declared in tokens.h)                    */
/* ------------------------------------------------------------------ */

static void add_token(TokenList *list, TokenType type, char *text, int line)
{
    if (list->count == list->capacity) {
        list->capacity = (list->capacity == 0) ? 64 : list->capacity * 2;
        list->items = (Token *) realloc(list->items, list->capacity * sizeof(Token));
        if (list->items == NULL) {
            printf("Out of memory\n");
            exit(1);
        }
    }
    list->items[list->count].type = type;
    list->items[list->count].text = text;
    list->items[list->count].line = line;
    list->count++;
}

/* Reads the whole file and stores every token in the list.
   The list always ends with a TOKEN_EOF token. */
int tokenize(FILE *input, TokenList *list)
{
    TokenType type;

    yyin = input;
    yylineno = 1;
    lex_error_count = 0;
    list->items = NULL;
    list->count = 0;
    list->capacity = 0;

    do {
        type = (TokenType) yylex();
        if (type == TOKEN_EOF)
            token_text = copy_text("end of file", 11);
        add_token(list, type, token_text, yylineno);
    } while (type != TOKEN_EOF);

    return lex_error_count;
}

const char *token_name(TokenType type)
{
    static const char *names[] = {
        [TOKEN_EOF] = "END_OF_FILE",
        [TYPE_INT] = "TYPE_INT", [TYPE_FLOAT] = "TYPE_FLOAT", [TYPE_CHAR] = "TYPE_CHAR",
        [KEYWORD_MAIN] = "KEYWORD_MAIN", [KEYWORD_RETURN] = "KEYWORD_RETURN",
        [KEYWORD_IF] = "KEYWORD_IF", [KEYWORD_ELSE] = "KEYWORD_ELSE",
        [KEYWORD_WHILE] = "KEYWORD_WHILE", [KEYWORD_FOR] = "KEYWORD_FOR",
        [KEYWORD_DO] = "KEYWORD_DO", [KEYWORD_BREAK] = "KEYWORD_BREAK",
        [KEYWORD_CONTINUE] = "KEYWORD_CONTINUE",
        [KEYWORD_PRINT] = "KEYWORD_PRINT", [KEYWORD_INPUT] = "KEYWORD_INPUT",
        [IDENTIFIER] = "IDENTIFIER", [INT_NUMBER] = "INT_NUMBER",
        [FLOAT_NUMBER] = "FLOAT_NUMBER", [CHAR_LITERAL] = "CHAR_LITERAL",
        [STRING_LITERAL] = "STRING_LITERAL",
        [OP_PLUS] = "OP_PLUS", [OP_MINUS] = "OP_MINUS", [OP_MUL] = "OP_MUL",
        [OP_DIV] = "OP_DIV", [OP_MOD] = "OP_MOD", [OP_INC] = "OP_INC", [OP_DEC] = "OP_DEC",
        [OP_ASSIGN] = "OP_ASSIGN", [OP_PLUS_ASSIGN] = "OP_PLUS_ASSIGN",
        [OP_MINUS_ASSIGN] = "OP_MINUS_ASSIGN", [OP_MUL_ASSIGN] = "OP_MUL_ASSIGN",
        [OP_DIV_ASSIGN] = "OP_DIV_ASSIGN", [OP_MOD_ASSIGN] = "OP_MOD_ASSIGN",
        [OP_EQ] = "OP_EQ", [OP_NE] = "OP_NE", [OP_LT] = "OP_LT",
        [OP_GT] = "OP_GT", [OP_LE] = "OP_LE", [OP_GE] = "OP_GE",
        [OP_AND] = "OP_AND", [OP_OR] = "OP_OR", [OP_NOT] = "OP_NOT",
        [OP_AMP] = "OP_AMP", [OP_BIT_OR] = "OP_BIT_OR", [OP_XOR] = "OP_XOR",
        [OP_TILDE] = "OP_TILDE", [OP_SHL] = "OP_SHL", [OP_SHR] = "OP_SHR",
        [OP_QUESTION] = "OP_QUESTION", [OP_COLON] = "OP_COLON",
        [SEMICOLON] = "SEMICOLON", [COMMA] = "COMMA",
        [LPAREN] = "LPAREN", [RPAREN] = "RPAREN",
        [LBRACE] = "LBRACE", [RBRACE] = "RBRACE",
        [LBRACKET] = "LBRACKET", [RBRACKET] = "RBRACKET"
    };
    return names[type];
}

void print_tokens(const TokenList *list)
{
    int i;
    for (i = 0; i < list->count; i++)
        printf("Line %-3d %-17s %s\n", list->items[i].line,
               token_name(list->items[i].type), list->items[i].text);
}
