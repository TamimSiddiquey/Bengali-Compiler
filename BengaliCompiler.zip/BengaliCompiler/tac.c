/*
 * tac.c - INTERMEDIATE CODE GENERATION: three-address code (TAC)
 *
 * Three-address code is the classic "intermediate code" from compiler
 * textbooks. Every instruction does at most ONE operation, with at most
 * three addresses (two operands and one result):
 *
 *     ক = ২ + ৩ * ৪;        becomes        t1 = 3 * 4
 *                                          t2 = 2 + t1
 *                                          ক = t2
 *
 * t1, t2 ... are temporary variables. Loops and if-else become labels
 * (L1:) and jumps (goto L1, ifFalse t1 goto L2). Array elements use the
 * indexed forms  t1 = a[i]  and  a[i] = t1.
 *
 * Our compiler translates the syntax tree straight into C, so this module
 * does not feed the code generator. It prints the same program in TAC form
 * (bnc file.bn --tac) to show what a compiler's intermediate code looks like,
 * for example what a compiler that produces assembly would work from.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tac.h"

#define MAX_LOOPS 100

static int temp_count;
static int label_count;

/* labels that থামো (break) and পরবর্তী (continue) jump to, innermost last */
static int break_label[MAX_LOOPS];
static int continue_label[MAX_LOOPS];
static int loops;

static char *new_temp(void)
{
    char name[16];
    sprintf(name, "t%d", ++temp_count);
    return copy_string(name);
}

static int new_label(void)
{
    return ++label_count;
}

static char *join(const char *a, const char *b, const char *c, const char *d)
{
    char *text = (char *) malloc(strlen(a) + strlen(b) + strlen(c) + strlen(d) + 1);
    if (text == NULL) {
        printf("Out of memory\n");
        exit(1);
    }
    sprintf(text, "%s%s%s%s", a, b, c, d);
    return text;
}

static char *tac_expression(const Node *node);

/* The place a value is stored:  ক   or   ক[t1]   or   ক[t1][t2] */
static char *tac_place(const Node *node)
{
    if (node->kind == NODE_INDEX) {
        char *array = tac_place(node->left);
        char *index = tac_expression(node->right);
        return join(array, "[", index, "]");
    }
    return copy_string(node->text);
}

/* Prints the instructions that compute an expression and returns the name
   that holds the result (a variable, a value, or a temporary). */
static char *tac_expression(const Node *node)
{
    char *a, *b, *place, *result;
    int else_label, end_label;

    if (node == NULL)
        return copy_string("");

    switch (node->kind) {
    case NODE_VAR:
        return copy_string(node->text);

    case NODE_INDEX:
        place = tac_place(node);
        if (node->type.ndims > 0)            /* a whole row, e.g. names[i] used with %s */
            return place;
        result = new_temp();
        printf("    %s = %s\n", result, place);
        return result;

    case NODE_UNARY:
        if (node->op == OP_AMP)
            return join("&", tac_place(node->left), "", "");
        if (node->op == OP_INC || node->op == OP_DEC) {      /* ++ক */
            place = tac_place(node->left);
            printf("    %s = %s %s 1\n", place, place, node->op == OP_INC ? "+" : "-");
            return place;
        }
        a = tac_expression(node->left);
        result = new_temp();
        printf("    %s = %s%s\n", result, op_text(node->op), a);
        return result;

    case NODE_POSTFIX:                                       /* ক++ */
        place = tac_place(node->left);
        result = new_temp();
        printf("    %s = %s\n", result, place);
        printf("    %s = %s %s 1\n", place, place, node->op == OP_INC ? "+" : "-");
        return result;

    case NODE_BINARY:
        if (node->op == COMMA) {                             /* a, b */
            tac_expression(node->left);
            return tac_expression(node->right);
        }
        a = tac_expression(node->left);
        b = tac_expression(node->right);
        result = new_temp();
        printf("    %s = %s %s %s\n", result, a, op_text(node->op), b);
        return result;

    case NODE_ASSIGN:
        b = tac_expression(node->right);
        place = tac_place(node->left);
        if (node->op == OP_ASSIGN) {
            printf("    %s = %s\n", place, b);
        } else {                                             /* ক += খ */
            char op[3];
            op[0] = op_text(node->op)[0];
            op[1] = '\0';
            result = new_temp();
            printf("    %s = %s %s %s\n", result, place, op, b);
            printf("    %s = %s\n", place, result);
        }
        return place;

    case NODE_CAST:
        a = tac_expression(node->left);
        result = new_temp();
        printf("    %s = (%s) %s\n", result, c_base_name(node->type.base), a);
        return result;

    case NODE_TERNARY:                                       /* c ? x : y */
        a = tac_expression(node->cond);
        result = new_temp();
        else_label = new_label();
        end_label = new_label();
        printf("    ifFalse %s goto L%d\n", a, else_label);
        b = tac_expression(node->left);
        printf("    %s = %s\n", result, b);
        printf("    goto L%d\n", end_label);
        printf("L%d:\n", else_label);
        b = tac_expression(node->right);
        printf("    %s = %s\n", result, b);
        printf("L%d:\n", end_label);
        return result;

    default:            /* number, character or text: no work needed */
        return copy_string(node->text);
    }
}

/* Array first values:  ক[0] = 1,  ক[1] = 2 ... */
static void tac_array_values(const char *place, const Node *value)
{
    const Node *item;
    int i = 0;
    char index[24];

    if (value->kind != NODE_INIT_LIST) {         /* অক্ষর নাম[] = "..." */
        printf("    %s = %s\n", place, value->text);
        return;
    }
    for (item = value->list; item != NULL; item = item->next, i++) {
        char *element;
        sprintf(index, "%d", i);
        element = join(place, "[", index, "]");
        if (item->kind == NODE_INIT_LIST || item->kind == NODE_STRING)
            tac_array_values(element, item);
        else
            printf("    %s = %s\n", element, tac_expression(item));
    }
}

static void tac_statement(const Node *node);

static void tac_loop_body(const Node *body, int break_to, int continue_to)
{
    if (loops < MAX_LOOPS) {
        break_label[loops] = break_to;
        continue_label[loops] = continue_to;
    }
    loops++;
    tac_statement(body);
    loops--;
}

static void tac_statement(const Node *node)
{
    const Node *item;
    int else_label, end_label, start_label, next_label;
    char *cond;

    if (node == NULL)
        return;

    switch (node->kind) {
    case NODE_PROGRAM:
        tac_statement(node->body);
        break;

    case NODE_BLOCK:
        for (item = node->list; item != NULL; item = item->next)
            tac_statement(item);
        break;

    case NODE_DECL:
        for (item = node->list; item != NULL; item = item->next) {
            if (item->value == NULL)
                continue;
            if (item->type.ndims > 0)
                tac_array_values(item->text, item->value);
            else
                printf("    %s = %s\n", item->text, tac_expression(item->value));
        }
        break;

    case NODE_EXPR_STMT:
        tac_expression(node->left);
        break;

    case NODE_PRINT:
    case NODE_INPUT: {
        /* first compute every value, then print / read them all */
        char *values[64];
        int count = 0, i;
        for (item = node->list; item != NULL && count < 64; item = item->next)
            values[count++] = tac_expression(item);
        printf("    %s %s", node->kind == NODE_PRINT ? "print" : "read", node->value->text);
        for (i = 0; i < count; i++)
            printf(", %s", values[i]);
        printf("\n");
        break;
    }

    case NODE_IF:
        cond = tac_expression(node->cond);
        else_label = new_label();
        printf("    ifFalse %s goto L%d\n", cond, else_label);
        tac_statement(node->body);
        if (node->else_body != NULL) {
            end_label = new_label();
            printf("    goto L%d\n", end_label);
            printf("L%d:\n", else_label);
            tac_statement(node->else_body);
            printf("L%d:\n", end_label);
        } else {
            printf("L%d:\n", else_label);
        }
        break;

    case NODE_WHILE:
        start_label = new_label();
        end_label = new_label();
        printf("L%d:\n", start_label);
        cond = tac_expression(node->cond);
        printf("    ifFalse %s goto L%d\n", cond, end_label);
        tac_loop_body(node->body, end_label, start_label);
        printf("    goto L%d\n", start_label);
        printf("L%d:\n", end_label);
        break;

    case NODE_DO:
        start_label = new_label();
        next_label = new_label();
        end_label = new_label();
        printf("L%d:\n", start_label);
        tac_loop_body(node->body, end_label, next_label);
        printf("L%d:\n", next_label);
        cond = tac_expression(node->cond);
        printf("    if %s goto L%d\n", cond, start_label);
        printf("L%d:\n", end_label);
        break;

    case NODE_FOR:
        if (node->init != NULL) {
            if (node->init->kind == NODE_DECL)
                tac_statement(node->init);
            else
                tac_expression(node->init);
        }
        start_label = new_label();
        next_label = new_label();
        end_label = new_label();
        printf("L%d:\n", start_label);
        if (node->cond != NULL) {
            cond = tac_expression(node->cond);
            printf("    ifFalse %s goto L%d\n", cond, end_label);
        }
        tac_loop_body(node->body, end_label, next_label);
        printf("L%d:\n", next_label);
        tac_expression(node->update);
        printf("    goto L%d\n", start_label);
        printf("L%d:\n", end_label);
        break;

    case NODE_BREAK:
        if (loops > 0 && loops <= MAX_LOOPS)
            printf("    goto L%d\n", break_label[loops - 1]);
        break;

    case NODE_CONTINUE:
        if (loops > 0 && loops <= MAX_LOOPS)
            printf("    goto L%d\n", continue_label[loops - 1]);
        break;

    case NODE_RETURN:
        printf("    return %s\n", tac_expression(node->value));
        break;

    default:
        break;
    }
}

void tac_print(const Node *program)
{
    temp_count = 0;
    label_count = 0;
    loops = 0;
    tac_statement(program);
}
