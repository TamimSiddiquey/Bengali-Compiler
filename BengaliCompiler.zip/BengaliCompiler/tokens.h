/*
 * tokens.h - the list of token types, shared by the lexer and the parser.
 *
 * The lexer (project.l) cuts the source file into tokens.
 * The parser (parser.c) reads those tokens.
 * Both must agree on what each token number means, so the list lives here,
 * in one place, and both files include it.
 */
#ifndef TOKENS_H
#define TOKENS_H

#include <stdio.h>

typedef enum {
    TOKEN_EOF = 0,          /* end of the file (must be 0: yylex() returns 0 at the end) */

    /* data types */
    TYPE_INT,               /* পূর্ণসংখ্যা   int    */
    TYPE_FLOAT,             /* দশমিক        float  */
    TYPE_CHAR,              /* অক্ষর         char   */

    /* keywords */
    KEYWORD_MAIN,           /* প্রধান        main     */
    KEYWORD_RETURN,         /* ফেরত         return   */
    KEYWORD_IF,             /* যদি          if       */
    KEYWORD_ELSE,           /* নাহলে        else     */
    KEYWORD_WHILE,          /* যতক্ষণ       while    */
    KEYWORD_FOR,            /* গণনার জন্য    for      */
    KEYWORD_DO,             /* করো          do       */
    KEYWORD_BREAK,          /* থামো         break    */
    KEYWORD_CONTINUE,       /* পরবর্তী       continue */
    KEYWORD_PRINT,          /* দেখাও        printf   */
    KEYWORD_INPUT,          /* নাও          scanf    */

    /* names and values */
    IDENTIFIER,             /* a variable name, e.g. বয়স   */
    INT_NUMBER,             /* ২৫  25                      */
    FLOAT_NUMBER,           /* ৩.১৪  3.14  .5  2e3         */
    CHAR_LITERAL,           /* 'A'  '\n'                   */
    STRING_LITERAL,         /* "হ্যালো %d\n"               */

    /* arithmetic */
    OP_PLUS, OP_MINUS, OP_MUL, OP_DIV, OP_MOD,     /* + - * / %  */
    OP_INC, OP_DEC,                                /* ++ --      */

    /* assignment */
    OP_ASSIGN,                                     /* =          */
    OP_PLUS_ASSIGN, OP_MINUS_ASSIGN,               /* += -=      */
    OP_MUL_ASSIGN, OP_DIV_ASSIGN, OP_MOD_ASSIGN,   /* *= /= %=   */

    /* comparison */
    OP_EQ, OP_NE, OP_LT, OP_GT, OP_LE, OP_GE,      /* == != < > <= >= */

    /* logical (the Bengali word and the C symbol give the same token) */
    OP_AND,                 /* এবং  &&  */
    OP_OR,                  /* অথবা ||  */
    OP_NOT,                 /* না   !   */

    /* bitwise; & is also "address of", used in নাও("%d", &ক) */
    OP_AMP, OP_BIT_OR, OP_XOR, OP_TILDE,           /* & | ^ ~    */
    OP_SHL, OP_SHR,                                /* << >>      */

    /* conditional operator  a ? b : c */
    OP_QUESTION, OP_COLON,

    /* punctuation */
    SEMICOLON, COMMA,                              /* ; ,        */
    LPAREN, RPAREN,                                /* ( )        */
    LBRACE, RBRACE,                                /* { }        */
    LBRACKET, RBRACKET                             /* [ ]        */
} TokenType;

/* One token: what kind it is, its text, and where it was found. */
typedef struct {
    TokenType type;
    char *text;     /* text as written (numbers are converted to English digits) */
    int line;       /* line number in the source file */
} Token;

/* A growable list of tokens. The lexer fills it, the parser reads it. */
typedef struct {
    Token *items;
    int count;
    int capacity;
} TokenList;

/* These three functions are written in project.l */
int         tokenize(FILE *input, TokenList *list);  /* returns the number of lexical errors */
const char *token_name(TokenType type);              /* e.g. KEYWORD_IF -> "KEYWORD_IF" */
void        print_tokens(const TokenList *list);

#endif
