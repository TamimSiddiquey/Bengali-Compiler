# Bengali C Compiler (`bnc`)

**Bengali C** is the C programming language written with Bengali keywords.
Every Bengali keyword stands for exactly one C keyword or function, and
programs follow C's structure and C's rules. `bnc` reads a Bengali C program
(`.bn` file), checks it for mistakes, translates it into C line by line,
compiles that C code with GCC and runs it.

```
পূর্ণসংখ্যা প্রধান()                      int main()
{                                       {
    পূর্ণসংখ্যা বয়স = ২৫;                     int v_1 = 25;   /* v_1 = বয়স */
    দেখাও("বয়স: %d\n", বয়স + ১);    ──►      printf("বয়স: %d\n", v_1 + 1);
    ফেরত ০;                                 return 0;
}                                       }
```

Built with **C + Flex** only (no Bison). The parser is a hand-written
recursive-descent parser.

---

## Contents

1. [Quick start](#1-quick-start)
2. [The language](#2-the-language)
3. [How the compiler works](#3-how-the-compiler-works)
4. [One program through every phase](#4-one-program-through-every-phase)
5. [Each phase in detail](#5-each-phase-in-detail)
6. [The grammar](#6-the-grammar)
7. [Errors and warnings](#7-errors-and-warnings)
8. [Bengali text and UTF-8](#8-bengali-text-and-utf-8)
9. [Testing](#9-testing)
10. [What is not included](#10-what-is-not-included)
11. [Viva questions and answers](#11-viva-questions-and-answers)

---

## 1. Quick start

**Requirements:** `flex` and `gcc` available in CMD (`flex --version`, `gcc --version`).
Tested with Flex 2.5.4.

Open CMD in the `BengaliCompiler` folder:

```
build
bnc project.bn
```

`build.bat` runs Flex and GCC once and creates `bnc.exe`, the compiler.
After that, any Bengali C program runs with `bnc <file>.bn`. Expected output
of `bnc project.bn` (when you type 20):

```
Compiling project.bn

[1] Lexical analysis .... OK (75 tokens)
[2] Syntax analysis ..... OK (syntax tree built)
[3] Semantic analysis ... OK (3 variables, 0 warnings)
[4] Code generation ..... OK -> output.c
[5] GCC compilation ..... OK -> program.exe

========== PROGRAM OUTPUT ==========
বয়স লিখুন: 20
রহিম ভোট দিতে পারবে
1
2
3
========== END ==========
```

- The lines `[1]` to `[5]` are the compiler at work.
- The part between `PROGRAM OUTPUT` and `END` is what the Bengali program printed.

### Options

| Command | Shows |
|---|---|
| `bnc file.bn` | compile and run |
| `bnc file.bn --tokens` | the token list (lexical analysis) |
| `bnc file.bn --ast` | the syntax tree (syntax analysis) |
| `bnc file.bn --symbols` | the symbol table (semantic analysis) |
| `bnc file.bn --tac` | three-address code (intermediate code) |
| `bnc file.bn --all` | all four of the above |
| `bnc file.bn --no-run` | compile only, do not run |

`--all` is ideal for the presentation: it shows the output of every phase.

### Seeing Bengali correctly

`bnc` switches the console to UTF-8 by itself (`chcp 65001`). Use
**Windows Terminal** (built into Windows 11); the old CMD window cannot draw
joined Bengali letters properly. If letters still look broken, save the
output to a file and open it in VS Code:

```
bnc project.bn --all > result.txt
code result.txt
```

If you run `program.exe` on its own in a new window, type `chcp 65001` first.

---

## 2. The language

### Keywords

| Bengali C | C | | Bengali C | C |
|---|---|---|---|---|
| `পূর্ণসংখ্যা` | `int` | | `করো` | `do` |
| `দশমিক` | `float` | | `থামো` | `break` |
| `অক্ষর` | `char` | | `পরবর্তী` | `continue` |
| `প্রধান` | `main` | | `ফেরত` | `return` |
| `যদি` | `if` | | `দেখাও` | `printf` |
| `নাহলে` | `else` | | `নাও` | `scanf` |
| `যতক্ষণ` | `while` | | `এবং` | `&&` |
| `গণনার জন্য` | `for` | | `অথবা` | `\|\|` |
| | | | `না` | `!` |

The symbols `&&`, `||` and `!` also work.

### A complete program

```
পূর্ণসংখ্যা প্রধান()
{
    পূর্ণসংখ্যা নম্বর[৫] = {৮০, ৭৫, ৯০, ৬৫, ৮৫};
    পূর্ণসংখ্যা মোট = ০;
    অক্ষর নাম[৩০];

    দেখাও("আপনার নাম: ");
    নাও("%s", নাম);

    গণনার জন্য (পূর্ণসংখ্যা i = ০; i < ৫; i++)
        মোট += নম্বর[i];

    যদি (মোট / ৫ >= ৮০)
        দেখাও("%s, আপনার গ্রেড A+\n", নাম);
    নাহলে
        দেখাও("%s, গড় %.2f\n", নাম, (দশমিক) মোট / ৫);

    ফেরত ০;
}
```

### What is included (all with C's meaning)

- **Program:** `পূর্ণসংখ্যা প্রধান() { ... }`, with all code inside it.
- **Types:** `পূর্ণসংখ্যা` (int), `দশমিক` (float), `অক্ষর` (char).
- **Variables:**
  - several in one declaration: `পূর্ণসংখ্যা ক = ১, খ, গ = ৩;`
  - declarations anywhere in a block, like C99
- **Arrays:**
  - with up to 4 dimensions: `পূর্ণসংখ্যা ক[১০];`, `পূর্ণসংখ্যা ম[২][৩];`
  - first values: `= {১, ২, ৩}`, `= {{১, ২}, {৩, ৪}}`
  - size taken from the values: `পূর্ণসংখ্যা ক[] = {...};`
- **Strings:** `অক্ষর` arrays, as in C: `অক্ষর নাম[২০] = "রহিম";` or `অক্ষর নাম[] = "রহিম";`
- **Statements:** `যদি` / `নাহলে`, `যতক্ষণ`, `করো ... যতক্ষণ`, `গণনার জন্য`
  (also with a declaration: `গণনার জন্য (পূর্ণসংখ্যা i = ০; ...)`),
  `থামো`, `পরবর্তী`, `ফেরত`, blocks `{ }`, the empty statement `;`.
- **Bodies without `{ }`:** a single statement is enough, as in C.
  `নাহলে` belongs to the nearest `যদি` (the dangling-else rule).
- **Input and output:** `দেখাও` = `printf`, `নাও` = `scanf`, with the same format codes.
- **Operators:** all of these, with C's precedence (section 5).
  ```
  + - * / %   ++ --   = += -= *= /= %=   == != < > <= >=
  && || !   & | ^ ~ << >>   ? :   ,   (type) casts   [ ]
  ```
- **Numbers:** Bengali or English digits, `২৫` / `25`, `৩.১৪` / `.৫` / `২e৩`.
- **Comments:** `// ...` and `/* ... */`.

### দেখাও (printf) format codes

| Code | Value |
|---|---|
| `%d` `%i` `%u` `%x` `%X` `%o` | পূর্ণসংখ্যা or অক্ষর |
| `%c` | অক্ষর or পূর্ণসংখ্যা |
| `%f` `%e` `%g` (also `%lf`) | দশমিক |
| `%s` | an অক্ষর array (text) |
| `%%` | prints `%` |

Flags, width and precision work as in C: `%5d`, `%-10s`, `%.2f`, `%*d`, `%03d`.

### নাও (scanf) format codes

| Code | Value |
|---|---|
| `%d` `%i` `%u` `%x` `%o` | `&` + a পূর্ণসংখ্যা variable: `&ক` |
| `%c` | `&` + an অক্ষর variable (use `" %c"` to skip spaces and new lines) |
| `%f` `%e` `%g` | `&` + a দশমিক variable |
| `%s` | an অক্ষর array, **without** `&`: `নাম` |
| `%*d` | read a value and throw it away |

### Type rules (C's rules)

- পূর্ণসংখ্যা, দশমিক and অক্ষর can be mixed in arithmetic. The result is
  দশমিক if either side is দশমিক, otherwise পূর্ণসংখ্যা.
- `পূর্ণসংখ্যা / পূর্ণসংখ্যা` drops the fraction: `৭ / ২` is `3`.
  Use `(দশমিক) ৭ / ২` to get `3.5`.
- `%`, `<<`, `>>`, `&`, `|`, `^` and `~` need whole numbers.
- Comparisons and `&& || !` give `1` (true) or `0` (false).
- A দশমিক value can be stored in a পূর্ণসংখ্যা variable; the fraction is
  dropped, and `bnc` shows a warning.
- A whole array cannot be assigned (`নাম = "করিম";` is an error, as in C).
- A variable declared without a value has no value yet, as in C.

---

## 3. How the compiler works

```
 project.bn  (Bengali C)
     │
     ▼
 [1] LEXICAL ANALYSIS      project.l  (Flex)
     │   characters  ──►  tokens
     ▼
 [2] SYNTAX ANALYSIS       parser.c
     │   tokens  ──►  syntax tree (AST)
     ▼
 [3] SEMANTIC ANALYSIS     semantic.c + symbol_table.c
     │   meaning, types, printf/scanf formats, symbol table
     ▼
     INTERMEDIATE CODE     tac.c  (three-address code, shown with --tac)
     │
 [4] CODE GENERATION       code_generator.c
     │   syntax tree  ──►  output.c
     ▼
 [5] GCC                   gcc -std=c99 output.c -o program.exe
     │
     ▼
 program.exe runs
```

The compiler is a **source-to-source compiler**: its target language is C
instead of machine code, and GCC does the last step. This is a well-known
design; the first C++ compiler (Cfront) translated C++ into C the same way.

### Files

| File | Phase | What it does |
|---|---|---|
| `tokens.h` | 1–2 | List of token types, shared by lexer and parser |
| `project.l` | 1 | Flex rules: turns the source text into tokens |
| `lex.yy.c` | 1 | Generated by Flex from `project.l` (do not edit) |
| `ast.h`, `ast.c` | 2 | Syntax tree nodes and types; printing the tree |
| `parser.h`, `parser.c` | 2 | Recursive-descent parser: tokens → syntax tree |
| `symbol_table.h`, `symbol_table.c` | 3 | The table of variables, with scopes |
| `semantic.h`, `semantic.c` | 3 | Declarations, C type rules, format checking |
| `tac.h`, `tac.c` | — | Prints three-address (intermediate) code |
| `code_generator.h`, `code_generator.c` | 4 | Syntax tree → C code in `output.c` |
| `main.c` | all | Runs the phases in order, calls GCC, runs the program |
| `build.bat` | | Builds `bnc.exe` |
| `run_tests.bat` | | Runs every program in `tests\` |
| `project.bn` | | Main sample program |
| `tests\` | | Test programs (correct ones, and ones with mistakes) |

### How Flex and C work together

Flex reads `project.l` and writes `lex.yy.c`, which contains the function
`yylex()`. Each call returns the type of the next token. `tokenize()` (at the
bottom of `project.l`) calls `yylex()` until the end of the file and stores
every token in a list; the parser then walks through that list. All the `.c`
files are compiled together into `bnc.exe`:

```
flex project.l
gcc lex.yy.c parser.c ast.c symbol_table.c semantic.c tac.c code_generator.c main.c -o bnc.exe
```

---

## 4. One program through every phase

Real output of `bnc example.bn --all` for this program:

```
পূর্ণসংখ্যা প্রধান()
{
    পূর্ণসংখ্যা বয়স = ২৫;
    দেখাও("বয়স: %d\n", বয়স + ১);
    ফেরত ০;
}
```

### Phase 1: tokens

The lexer cuts the text into tokens. Bengali digits are converted (`২৫` → `25`).

```
Line 1   TYPE_INT          পূর্ণসংখ্যা
Line 1   KEYWORD_MAIN      প্রধান
Line 1   LPAREN            (
Line 1   RPAREN            )
Line 2   LBRACE            {
Line 3   TYPE_INT          পূর্ণসংখ্যা
Line 3   IDENTIFIER        বয়স
Line 3   OP_ASSIGN         =
Line 3   INT_NUMBER        25
Line 3   SEMICOLON         ;
Line 4   KEYWORD_PRINT     দেখাও
Line 4   LPAREN            (
Line 4   STRING_LITERAL    "বয়স: %d\n"
Line 4   COMMA             ,
Line 4   IDENTIFIER        বয়স
Line 4   OP_PLUS           +
Line 4   INT_NUMBER        1
Line 4   RPAREN            )
Line 4   SEMICOLON         ;
Line 5   KEYWORD_RETURN    ফেরত
Line 5   INT_NUMBER        0
Line 5   SEMICOLON         ;
Line 6   RBRACE            }
Line 7   END_OF_FILE       end of file
```

### Phase 2: syntax tree

```
PROGRAM  পূর্ণসংখ্যা প্রধান()
|   BLOCK
|   |   DECLARE পূর্ণসংখ্যা  (line 3)
|   |   |   VARIABLE বয়স  : পূর্ণসংখ্যা
|   |   |   |   INITIAL VALUE
|   |   |   |   |   INT 25
|   |   PRINT (printf)  (line 4)
|   |   |   STRING "বয়স: %d\n"
|   |   |   BINARY +
|   |   |   |   VARIABLE বয়স
|   |   |   |   INT 1
|   |   RETURN  (line 5)
|   |   |   INT 0
```

### Phase 3: symbol table

```
C name  C type         Line  Scope  Bengali name : type
------- -------------- ----- ------ --------------------
v_1     int            3     1      বয়স : পূর্ণসংখ্যা
```

Semantic analysis also checked that `%d` gets a whole number: `বয়স + ১` is a
পূর্ণসংখ্যা, so it is correct.

### Intermediate code: three-address code

```
    বয়স = 25
    t1 = বয়স + 1
    print "বয়স: %d\n", t1
    return 0
```

### Phase 4: generated C (`output.c`)

```c
/* Generated by bnc, the Bengali C compiler, from example.bn */
#include <stdio.h>

int main()
{
    int v_1 = 25;   /* v_1 = বয়স */
    printf("বয়স: %d\n", v_1 + 1);
    return 0;
}
```

### Phase 5: GCC and run

```
বয়স: 26
```

---

## 5. Each phase in detail

### Phase 1: Lexical analysis (`project.l`)

- **Token**: the smallest meaningful unit: a keyword, a name, a number, an operator.
- **Lexeme**: the actual text of a token, for example `বয়স`.
- **Pattern**: the rule (regular expression) that describes a token.

Flex works with **bytes**, not letters. In UTF-8, each Bengali character is
3 bytes: `E0`, then `A6` or `A7`, then one more byte. The patterns describe
Bengali by its bytes:

```
BN_LETTER   \xE0\xA6[\x80-\xBF]|\xE0\xA7[\x80-\xA5]     U+0980 – U+09E5
BN_DIGIT    \xE0\xA7[\xA6-\xAF]                          ০ – ৯
```

**How Flex picks a rule** when several patterns match:

1. **Longest match wins.**
   - `নাম` is one IDENTIFIER, not the keyword `না` + `ম`.
   - `++` is one token, not `+` `+`.
   - `<=` is one token, not `<` `=`.
2. **On a tie, the earlier rule wins.**
   - `যদি` matches the keyword rule and the identifier rule with the same length.
   - The keyword rule is written first, so it wins.
   - That is why all keyword rules come before the identifier rule.

Other jobs of the lexer:
- converting Bengali digits to English digits (`৩.১৪` → `3.14`)
- skipping spaces, `// comments` and `/* comments */`
  (multi-line comments use a Flex **start condition**, `%x COMMENT`)
- skipping the invisible BOM some editors add to a file
- treating the two ways of typing য়/ড়/ঢ় as the same letter (section 8)
- reporting unknown characters, unclosed text and unclosed comments, then
  **continuing**, so every lexical error appears in one run

### Phase 2: Syntax analysis (`parser.c`)

The parser checks the **structure** of the program against the grammar
(section 6) and builds the **abstract syntax tree (AST)**.

It is a **recursive-descent parser**: one C function per grammar rule
(`parse_if()`, `parse_for()`, `parse_declaration()` ...). It mostly needs one
token of lookahead. In one place it looks two tokens ahead: to tell a cast
`(দশমিক) ক` from a bracketed expression `(ক)`.

**Operator precedence** is exactly C's. Each level is one function, and a
function lower in the chain binds tighter:

| Level (loosest first) | Operators | Function |
|---|---|---|
| 1 | `,` | `parse_expression` |
| 2 | `= += -= *= /= %=` (right to left) | `parse_assignment` |
| 3 | `? :` | `parse_conditional` |
| 4 | `\|\|` `অথবা` | `parse_logical_or` |
| 5 | `&&` `এবং` | `parse_logical_and` |
| 6 | `\|` | `parse_bit_or` |
| 7 | `^` | `parse_bit_xor` |
| 8 | `&` | `parse_bit_and` |
| 9 | `== !=` | `parse_equality` |
| 10 | `< > <= >=` | `parse_relational` |
| 11 | `<< >>` | `parse_shift` |
| 12 | `+ -` | `parse_additive` |
| 13 | `* / %` | `parse_term` |
| 14 | `(type)` cast | `parse_cast` |
| 15 | `- + ! ~ & ++ --` (prefix) | `parse_unary` |
| 16 | `[ ]`, `++ --` (postfix) | `parse_postfix` |

**Left recursion:** the rule `additive → additive + term` would make
`parse_additive()` call itself forever, so each rule uses a loop instead:
`additive → term ( + term )*`. The loop also makes the operators
left-associative: `১০ - ৩ - ২` is `(10 - 3) - 2`. Assignment calls itself on
the right side instead, so `ক = খ = ০` means `ক = (খ = ০)`, as in C.

**Dangling else:** in `যদি (a) যদি (b) x; নাহলে y;` the `নাহলে` belongs to
the inner `যদি`, exactly as in C. This happens naturally: the inner
`parse_if()` sees the `নাহলে` first and takes it.

### Phase 3: Semantic analysis (`semantic.c`, `symbol_table.c`)

The parser accepts `দেখাও("%d\n", উচ্চতা);` even if `উচ্চতা` was never
declared, because the grammar is fine. Semantic analysis checks the
**meaning**:

- each variable is declared before use, and only once per block
- the type of every expression, using C's rules (section 2)
- the targets of `=`, `++`, `--` and `&` are variables or array elements,
  never a whole array
- array sizes, `[ ]` used on non-arrays, too many values in `{ }`, text too
  long for its array
- `থামো` and `পরবর্তী` are inside a loop
- **every `দেখাও` / `নাও` format against its values**

**Symbol table:** for every variable it stores the name, type and array
sizes, the declaration line, the scope level, and a unique id (used for the
C name `v_<id>`).

**Scopes:** the table works like a stack.
- Each declaration is pushed onto it.
- At a `}`, every variable of that block is popped.
- A lookup searches from the top, so an inner variable hides an outer one.
- A variable declared in the first part of `গণনার জন্য` belongs only to that
  loop, as in C99.

**Format checking:** C compilers accept `printf("%d", 2.5)` and
`scanf("%d", x)`, but they print garbage or crash. `bnc` reads each format
string and checks every `%` code:

- `%d` needs a whole number, `%f` a দশমিক and `%s` an অক্ষর array.
- `নাও` needs `&` before variables, and no `&` before arrays.
- The number of `%` codes must match the number of values.

**One error, one message:** an expression with an error gets the type
`BT_ERROR`, and checks that see `BT_ERROR` stay silent.

**Warnings** are possible mistakes that are still legal C, so the program
still compiles and runs. Examples: storing a দশমিক in a পূর্ণসংখ্যা, `=` inside
a condition, a statement with no effect, and an array index that is clearly
out of range.

### Intermediate code (`tac.c`)

**Three-address code** is the classic intermediate code: each instruction
does at most one operation (`t1 = b * c`), and control flow becomes labels
and jumps (`ifFalse t1 goto L2`, `goto L1`). `থামো` becomes a jump to the
loop's end, and `পরবর্তী` a jump to the loop's next step.

In this project, the **syntax tree is the intermediate representation** that
the code generator uses. The TAC printer walks the same tree to show the
program as intermediate code, the way a compiler producing assembly would see it.

### Phase 4: Code generation (`code_generator.c`)

Bengali C has the same structure as C, so the translation is line by line:
each keyword becomes its C keyword and each variable becomes `v_<id>`.

- **Why `v_1` and not `বয়স`?** Many C compilers (including older MinGW) do
  not accept Bengali names. Unique numbers also keep an inner and an outer
  variable with the same Bengali name apart. Each declaration has a comment
  such as `/* v_1 = বয়স */`.
- **Brackets:** expressions are written with exactly the brackets the
  programmer used. Bengali C has C's precedence, so C reads every expression
  the same way our parser did.
- **Text and characters** (`"..."`, `'A'`) are copied unchanged, including
  `\n` and the `%` codes.

### Phase 5: GCC and running (`main.c`)

`main.c` runs every phase and stops as soon as one fails. Phases 1 and 2
both run even if phase 1 found errors, so lexical and syntax errors are
reported together. With no errors, it writes `output.c`, runs
`gcc -std=c99 output.c -o program.exe`, and then runs `program.exe`.

---

## 6. The grammar

`x*` means zero or more `x`, `[x]` means optional, `|` means "or".

```
program      → পূর্ণসংখ্যা প্রধান "(" ")" block END_OF_FILE
block        → "{" item* "}"
item         → declaration | statement
declaration  → type declarator ( "," declarator )* ";"
type         → পূর্ণসংখ্যা | দশমিক | অক্ষর
declarator   → IDENTIFIER ( "[" [INT_NUMBER] "]" )* [ "=" initializer ]
initializer  → assignment | "{" initializer ( "," initializer )* [","] "}"

statement    → block
             | [expression] ";"
             | দেখাও "(" STRING_LITERAL ( "," assignment )* ")" ";"
             | নাও   "(" STRING_LITERAL ( "," assignment )* ")" ";"
             | যদি "(" expression ")" statement [ নাহলে statement ]
             | যতক্ষণ "(" expression ")" statement
             | করো statement যতক্ষণ "(" expression ")" ";"
             | গণনার জন্য "(" ( declaration | [expression] ";" )
                           [expression] ";" [expression] ")" statement
             | থামো ";" | পরবর্তী ";" | ফেরত expression ";"

expression   → assignment ( "," assignment )*
assignment   → conditional [ ( "=" | "+=" | "-=" | "*=" | "/=" | "%=" ) assignment ]
conditional  → logical_or [ "?" expression ":" conditional ]
logical_or   → logical_and ( ( "||" | অথবা ) logical_and )*
logical_and  → bit_or ( ( "&&" | এবং ) bit_or )*
bit_or       → bit_xor ( "|" bit_xor )*
bit_xor      → bit_and ( "^" bit_and )*
bit_and      → equality ( "&" equality )*
equality     → relational ( ( "==" | "!=" ) relational )*
relational   → shift ( ( "<" | ">" | "<=" | ">=" ) shift )*
shift        → additive ( ( "<<" | ">>" ) additive )*
additive     → term ( ( "+" | "-" ) term )*
term         → cast ( ( "*" | "/" | "%" ) cast )*
cast         → "(" type ")" cast | unary
unary        → ( "++" | "--" ) unary | ( "-" | "+" | "!" | না | "~" | "&" ) cast | postfix
postfix      → primary ( "[" expression "]" | "++" | "--" )*
primary      → IDENTIFIER | INT_NUMBER | FLOAT_NUMBER | CHAR_LITERAL
             | STRING_LITERAL | "(" expression ")"
```

As in C, a declaration is an `item` but not a `statement`, so
`যদি (ক) পূর্ণসংখ্যা খ;` is a syntax error. The declaration must go inside `{ }`.

---

## 7. Errors and warnings

Every message shows the line number and the phase that found it. These are
real outputs from the test files.

### Lexical errors (`tests\e1_lexical_errors.bn`)

```
Line 4: Lexical error: unknown character '৳' (it is not part of the language)
Line 5: Lexical error: unknown symbol '@' (it is not part of the language)
Line 6: Lexical error: 'ক' is not a valid অক্ষর value: use exactly one English character, like 'a'
Line 7: Lexical error: the text "শেষ নেই); has no closing " on this line
Line 10: Lexical error: this comment is never closed with */
[1] Lexical analysis .... FAILED (5 errors)
Line 7: Syntax error: expected ')' after the values of দেখাও, but found 'ফেরত'
[2] Syntax analysis ..... FAILED (1 error)
```

The syntax error is a follow-up: the unclosed text on line 7 swallowed the `)`.

### Syntax errors (`tests\e2_syntax_errors.bn`)

```
Line 4: Syntax error: expected ';' at the end of the declaration, but found 'দেখাও'
Line 6: Syntax error: 'দেখা' is not a function. Did you misspell দেখাও or নাও? (other functions are not part of this language)
Line 7: Syntax error: expected '(' after যদি, but found 'ক'
Line 8: Syntax error: the first value of দেখাও must be a format text in quotes, like দেখাও("%d\n", ক);
Line 9: Syntax error: expected a variable name after 'পূর্ণসংখ্যা', but found '='
Line 10: Syntax error: expected 'যতক্ষণ' after the body of করো  (করো { ... } যতক্ষণ (...);), but found '('
Line 11: Syntax error: ফেরত needs a value here, because প্রধান() returns a পূর্ণসংখ্যা: ফেরত ০;
```

- A missing `;` is reported on the line where it is missing (line 4), not
  on the line where the parser noticed it.
- **Error recovery (panic mode):** after an error, the parser stops
  reporting, skips to the next `;` or statement keyword, and continues. That
  is how one run finds all seven errors.

### Semantic errors (`tests\e3_semantic_errors.bn`)

```
Line 5: Semantic error: variable 'বয়স' is already declared on line 4
Line 6: Semantic error: variable 'উচ্চতা' is used but was never declared
Line 8: Semantic error: দেখাও: %d needs a whole number, but value 1 is দশমিক (use %f, or convert it with (পূর্ণসংখ্যা))
Line 9: Semantic error: নাও: %d needs the address of the variable: write &বয়স (without & the program crashes)
Line 10: Semantic error: the text needs 13 bytes (including the hidden '\0' at the end), but 'নাম' has room for 5. Each Bengali letter takes 3 bytes
Line 11: Semantic error: cannot assign to the whole array 'নাম' (C does not allow it); assign one element at a time
Line 12: Semantic error: দেখাও: the format has %d, but no value is given for it
Line 13: Semantic error: '%' needs whole numbers (পূর্ণসংখ্যা or অক্ষর), but got দশমিক and পূর্ণসংখ্যা
Line 14: Semantic error: থামো can only be used inside a loop (যতক্ষণ, গণনার জন্য or করো)
Line 15: Semantic error: & (address of) can only be used inside নাও(...), like নাও("%d", &ক);
```

### Missing প্রধান() (`tests\e4_missing_main.bn`)

```
Line 2: Syntax error: the program must start with  পূর্ণসংখ্যা প্রধান()  and all the code goes inside its { }
```

### Warnings (`tests\w1_warnings.bn`), the program still runs

```
Line 4: Warning: a দশমিক value is stored in the পূর্ণসংখ্যা 'ক', so the part after the decimal point is dropped
Line 5: Warning: '=' in the condition of যদি stores a value; to compare two values use '=='
Line 7: Warning: this '==' compares but stores nothing; to store a value use '='
Line 10: Warning: index 5 is outside the array 'তালিকা' (its indexes go from 0 to 2)
[3] Semantic analysis ... OK (2 variables, 4 warnings)
```

### Which phase catches what

| Mistake | Phase |
|---|---|
| unknown character, unclosed text or comment, Bengali letter in `'...'` | Lexical |
| missing `;` `(` `)` `{` `}`, misspelled keyword, missing `প্রধান()` | Syntax |
| undeclared / duplicate variable, wrong `%` code, missing `&`, array misuse, `থামো` outside a loop | Semantic |

If there is **any** error, no C code is generated. Invalid source is never
silently ignored.

---

## 8. Bengali text and UTF-8

1. **Files must be UTF-8.** In VS Code the status bar (bottom right) must
   say `UTF-8`. A file saved as UTF-16 gives "invalid byte" errors.
2. **BOM:** some editors put 3 invisible bytes (`EF BB BF`) at the start of
   a file. The lexer skips them in `.bn` files. Flex itself, however, rejects
   a `project.l` that starts with a BOM (`bad character` errors).
3. **Bytes vs letters:** `পূর্ণসংখ্যা` is 11 Unicode characters (letters,
   vowel signs, hasanta) = 33 bytes. Flex matches all 33 bytes.
4. **Array sizes count bytes:** `"রহিম"` needs 13 bytes (4 letters × 3 + the
   hidden `'\0'`). So `অক্ষর নাম[৫] = "রহিম";` is an error;
   `অক্ষর নাম[] = "রহিম";` picks the right size automatically.
5. **Two ways to type য়, ড়, ঢ়:** as one character (`য়` = U+09DF) or as a
   letter plus nukta (`য` + `়`). They look identical, so the lexer converts
   the second form to the first. That way `বয়স` is always the same variable.
6. **অক্ষর values are English-only:** a C `char` is 1 byte, a Bengali letter is 3.
7. **Console:** `bnc` runs `chcp 65001` so Bengali text is shown as UTF-8.

---

## 9. Testing

```
run_tests
run_tests > test_results.txt      (save the results to a file)
```

Input for `04_input.bn` comes from `tests\input.txt` (`Rahim`, `20`, `85.5`, `A`).

| Test | Checks | Result (verified) |
|---|---|---|
| `01_hello.bn` | `দেখাও` with text and `%d` | `হ্যালো, বিশ্ব!` / `আমার বয়স 22 বছর` |
| `02_variables.bn` | all types, several declarations, `%f %.1f %c %d %s %%` | `5.800000 বা 5.8`, `A (ASCII মান 65)`, `100%` |
| `03_operators.bn` | arithmetic, int division, cast, `++ -- += *=`, `?:` | `13`, `3`, `1`, `3.33`, `14`/`20`, `16`, `-16 0` |
| `04_input.bn` | `নাও` with `%s %d %f %c` | `স্বাগতম Rahim! ... 25`, `85.5`, `A` |
| `05_if_else.bn` | `নাহলে যদি`, bodies without `{ }`, dangling else | `গ্রেড: A`, `75 বিজোড়`, `শূন্য থেকে একশো` |
| `06_loops.bn` | `যতক্ষণ`, `গণনার জন্য`, `করো`, `থামো`, `পরবর্তী` | table of 5, `10`, `1 3 5 7 9` |
| `07_logic.bn` | `এবং অথবা না` and `&& \|\| !` | 4 lines, `সত্য = 1, মিথ্যা = 0` |
| `08_arrays.bn` | arrays, `{ }` values, strings, 2-D arrays | `মোট = 395, গড় = 79.00`, 3 names, a 2×3 matrix |
| `09_prime.bn` | nested loops, `থামো` | `2 3 5 7 11 13 17 19 23 29` |
| `10_bubble_sort.bn` | sorting an array | `11 12 22 25 34 64 90` |
| `11_factorial_fibonacci.bn` | loops, `*=` | `10! = 3628800`, `0 1 1 2 3 5 8 13 21 34` |
| `12_scope.bn` | inner variable hides outer one | `5`, then `100` |
| `w1_warnings.bn` | warnings, still runs | 4 warnings, `ক = 5` |
| `e1_lexical_errors.bn` | lexical errors | 5 lexical (+1 follow-up), rejected |
| `e2_syntax_errors.bn` | syntax errors + recovery | 7 syntax errors, rejected |
| `e3_semantic_errors.bn` | semantic errors | 10 semantic errors, rejected |
| `e4_missing_main.bn` | program without `প্রধান()` | 1 syntax error, rejected |

All results above were produced with Flex 2.5.4 and GCC. The generated C
code for every correct test compiles with `gcc -std=c99 -pedantic` without a
single warning, and also compiles with the Windows version of GCC (MinGW).

---

## 10. What is not included

Bengali C covers the C of a first programming course. Not included:

- functions other than `প্রধান()`, and global variables
- pointers (except `&` inside `নাও`), `struct`, `union`, `enum`
- `switch`, `goto`
- `double`, `long`, `short`, `unsigned`
- `#include`, `#define` and library functions such as `strlen` or `strcmp`
- hexadecimal or octal numbers (`0x1F`)
- Bengali letters in `অক্ষর` values ('ক' takes 3 bytes)

Other notes:
- Output uses English digits, and typed input must use English digits.
- Typing Bengali into a running program is unreliable in Windows consoles.

**Possible improvements:** user-defined functions, `switch`, `double`,
string functions (`strlen`, `strcmp`, `strcpy`), printing Bengali digits, a
Bison version of the parser, or generating assembly from the three-address code.

---

## 11. Viva questions and answers

**1. What is a compiler?**
A program that translates source code into another language, checking it for
errors on the way. Ours translates Bengali C into C.

**2. Is this a real compiler or just a translator?**
It is a compiler. It has every analysis phase (lexical, syntax, semantic),
builds a syntax tree and a symbol table, and checks types and formats. Its
target language is C, which makes it a source-to-source compiler, like Cfront
(the first C++ compiler).

**3. Why not just replace Bengali words with English words?**
- A replacer would also change words inside text, like `দেখাও("যদি")`.
- It could not detect a missing `)`, an undeclared variable, `%d` used with a
  দশমিক, or a missing `&` in `নাও`.
- It could not rename Bengali variables safely, or keep inner and outer
  variables apart.

**4. What are the phases of your compiler?**
1. Lexical analysis (Flex)
2. Syntax analysis (recursive descent)
3. Semantic analysis (symbol table, types, format checking)
4. Intermediate code (three-address code, for display)
5. Code generation (C)
6. GCC compiles the C into machine code

**5. What is a token? A lexeme? A pattern?**
- A **token** is a category, such as `IDENTIFIER` or `KEYWORD_IF`.
- A **lexeme** is the actual text, such as `বয়স`.
- A **pattern** is the regular expression describing which lexemes form a token.

**6. How does Flex handle Bengali?**
Flex has no Unicode support; it works on bytes. Bengali text is UTF-8, where
each character is 3 bytes beginning with `E0 A6` or `E0 A7`. Our patterns
describe those byte sequences.

**7. How does your lexer tell a keyword from a variable name?**
Longest match first, then the earliest rule. Keywords come before the
identifier rule, so `যদি` is a keyword. `যদিও` is longer as an identifier, so
it is a variable name.

**8. What is the syntax tree and why build one?**
A tree that shows the structure of the program without punctuation. All
later phases walk it, so each phase can be written, tested and explained on
its own. It also records how expressions are grouped (precedence).

**9. What kind of parser do you use?**
A hand-written, top-down, recursive-descent parser: one function per
grammar rule. It mostly uses one token of lookahead, and two tokens to
recognize a cast.

**10. Why didn't you use Bison/Yacc?**
Recursive descent handles this grammar well; GCC and Clang also use
hand-written recursive-descent parsers. Every line of our parser can be
explained, unlike Bison-generated code. The parser is a separate module, so
it could be replaced by a Bison parser without changing the other phases.

**11. How do you handle operator precedence?**
One function per precedence level (section 5). A function lower in the chain
binds tighter, so `২ + ৩ * ৪` is grouped as `2 + (3 * 4)`.

**12. What is left recursion, and how did you handle it?**
A rule like `E → E + T` refers to itself first, so a recursive-descent
function would call itself forever. We write `E → T ( + T )*` and use a
`while` loop, which also makes the operators left-associative.

**13. How does your parser solve the dangling-else problem?**
`নাহলে` belongs to the nearest `যদি`. The inner `parse_if()` looks for a
`নাহলে` right after its own statement, so it takes it first. C works the same way.

**14. What is a symbol table, and how do you handle scopes?**
The record of every variable: name, type with array sizes, line, scope and a
unique id. The visible symbols form a stack: a declaration pushes, a `}`
pops that block's symbols, and lookup searches from the top. So an inner
variable hides an outer one.

**15. What does semantic analysis check?**
- Undeclared and duplicate variables
- C type rules
- Assignments to non-variables or whole arrays
- Array sizes and first values
- `থামো` / `পরবর্তী` outside loops
- Every `দেখাও` / `নাও` format against its values

**16. Why check printf/scanf formats? C does not require it.**
In C, `printf("%d", 2.5)` prints garbage and `scanf("%d", x)` (without `&`)
usually crashes. Both are legal C, so they compile. `bnc` reads the format
string, matches each `%` code with its value, and reports the mistake before
the program runs.

**17. Why does `নাও` need `&`?**
`scanf` must store the value into the variable, so it needs the variable's
address. `&ক` means "the address of ক". An array name already acts as an
address, so `%s` takes `নাম` without `&`.

**18. Why is `নাম = "করিম";` an error?**
In C an array cannot be assigned as a whole; only its elements can. Our
compiler applies the same rule (an array is not an *lvalue* that can be
assigned).

**19. What is the difference between an error and a warning?**
An error breaks the language rules, and no code is generated. A warning is
legal C that is probably a mistake (e.g. `যদি (ক = ৫)`); the program still
compiles and runs.

**20. What is three-address code?**
Intermediate code where each instruction has at most one operator and three
addresses, such as `t1 = b * c`. Control flow becomes labels and jumps.
`থামো` jumps to the end of the loop, `পরবর্তী` to its next step.

**21. Why does the generated C use `v_1` instead of Bengali names?**
Many C compilers do not accept Bengali identifiers. Unique numbers also keep
an inner and an outer variable with the same name apart. The Bengali name is
kept in a comment.

**22. How does your parser recover from errors?**
Panic mode. After an error, further messages are suppressed and tokens are
skipped until a `;` or the start of a new statement. Then parsing continues,
so several errors are reported in one run.

**23. Why does `অক্ষর নাম[৫] = "রহিম";` fail?**
In UTF-8 each Bengali letter takes 3 bytes, so "রহিম" needs 12 bytes plus the
hidden `'\0'` = 13 bytes, and the array has only 5.

**24. How is Bengali C different from full C?**
It has the same structure, rules and precedence, but covers a subset: one
`প্রধান()` function, three types, arrays, and `printf`/`scanf`. There are no
pointers, structs, other functions or preprocessor (section 10).

**25. How would you produce machine code without GCC?**
Translate the three-address code into assembly instructions (instruction
selection, register allocation), then assemble and link the result.
