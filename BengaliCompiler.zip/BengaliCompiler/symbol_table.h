/*
 * symbol_table.h - the SYMBOL TABLE
 *
 * The compiler's notebook of variables. For every declared variable it
 * remembers the name, the type (with array sizes), where it was declared,
 * which { } block it belongs to, and the C name it will get in output.c.
 */
#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

#include "ast.h"

typedef struct Symbol {
    char *name;       /* name as written in the Bengali program, e.g. বয়স */
    Type type;        /* basic type, plus sizes if it is an array          */
    int line;         /* line where it was declared                        */
    int scope;        /* 1 = the body of প্রধান(), 2 = one { } deeper, ...    */
    int id;           /* unique number: the variable is called v_<id> in C */
} Symbol;

void    st_enter_scope(void);                 /* a '{' was found */
void    st_exit_scope(void);                  /* a '}' was found: its variables disappear */
Symbol *st_add(const char *name, Type type, int line);
Symbol *st_find(const char *name);            /* look in every visible scope, innermost first */
Symbol *st_find_in_current_scope(const char *name);
int     st_total(void);                       /* how many variables were declared in total */
void    st_print(void);                       /* print every variable ever declared */

#endif
