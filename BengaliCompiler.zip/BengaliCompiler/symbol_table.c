/*
 * symbol_table.c - the symbol table, with SCOPES
 *
 * A scope is the region where a variable can be used. As in C, a variable
 * declared inside { } exists only until the matching }.
 *
 * We keep two arrays:
 *   visible[] - a STACK of the variables that can be used right now.
 *               Each declaration pushes one symbol; leaving a } pops every
 *               symbol of that block.
 *   all[]     - every symbol ever created, kept so that --symbols can print
 *               the full table after the program has been checked.
 *
 * Looking a name up searches visible[] from the TOP down, so the innermost
 * declaration is found first (an inner বয়স hides an outer বয়স).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symbol_table.h"

static Symbol **visible = NULL;
static int visible_count = 0, visible_capacity = 0;

static Symbol **all = NULL;
static int all_count = 0, all_capacity = 0;

static int current_scope = 0;

static void push(Symbol ***array, int *count, int *capacity, Symbol *symbol)
{
    if (*count == *capacity) {
        *capacity = (*capacity == 0) ? 32 : *capacity * 2;
        *array = (Symbol **) realloc(*array, *capacity * sizeof(Symbol *));
        if (*array == NULL) {
            printf("Out of memory\n");
            exit(1);
        }
    }
    (*array)[(*count)++] = symbol;
}

void st_enter_scope(void)
{
    current_scope++;
}

void st_exit_scope(void)
{
    while (visible_count > 0 && visible[visible_count - 1]->scope == current_scope)
        visible_count--;
    current_scope--;
}

Symbol *st_add(const char *name, Type type, int line)
{
    Symbol *symbol = (Symbol *) malloc(sizeof(Symbol));
    if (symbol == NULL) {
        printf("Out of memory\n");
        exit(1);
    }
    symbol->name  = copy_string(name);
    symbol->type  = type;
    symbol->line  = line;
    symbol->scope = current_scope;
    symbol->id    = all_count + 1;

    push(&visible, &visible_count, &visible_capacity, symbol);
    push(&all, &all_count, &all_capacity, symbol);
    return symbol;
}

Symbol *st_find(const char *name)
{
    int i;
    for (i = visible_count - 1; i >= 0; i--)
        if (strcmp(visible[i]->name, name) == 0)
            return visible[i];
    return NULL;
}

Symbol *st_find_in_current_scope(const char *name)
{
    int i;
    for (i = visible_count - 1; i >= 0 && visible[i]->scope == current_scope; i--)
        if (strcmp(visible[i]->name, name) == 0)
            return visible[i];
    return NULL;
}

int st_total(void)
{
    return all_count;
}

void st_print(void)
{
    int i, d;
    printf("%-7s %-14s %-5s %-6s %s\n", "C name", "C type", "Line", "Scope", "Bengali name : type");
    printf("------- -------------- ----- ------ --------------------\n");
    for (i = 0; i < all_count; i++) {
        char c_name[32], c_type[64], bengali_type[100];
        Symbol *s = all[i];

        sprintf(c_name, "v_%d", s->id);
        strcpy(c_type, c_base_name(s->type.base));
        for (d = 0; d < s->type.ndims; d++)
            sprintf(c_type + strlen(c_type), "[%d]", s->type.dims[d]);
        describe_type(s->type, bengali_type);

        printf("%-7s %-14s %-5d %-6d %s : %s\n", c_name, c_type, s->line, s->scope,
               s->name, bengali_type);
    }
    if (all_count == 0)
        printf("(no variables)\n");
}
