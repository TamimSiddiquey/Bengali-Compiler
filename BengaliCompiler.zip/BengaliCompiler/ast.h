/*
 * ast.h - the ABSTRACT SYNTAX TREE (AST)
 *
 * The parser turns the list of tokens into a tree. Each statement and each
 * part of an expression becomes a Node. Punctuation such as ; { } is not
 * stored: the shape of the tree already says what belongs together.
 *
 * Example:  ক = ২ + ৩ * ৪;
 *
 *     EXPRESSION
 *       └─ ASSIGN =
 *            ├─ VARIABLE ক
 *            └─ BINARY +
 *                 ├─ INT 2
 *                 └─ BINARY *
 *                      ├─ INT 3
 *                      └─ INT 4
 *
 * The later phases (semantic analysis, three-address code, code generation)
 * all walk this same tree, so it is the "intermediate representation"
 * that connects the front end of the compiler to the back end.
 *
 * To keep things simple, one struct is used for every kind of node.
 * Each kind uses only some of the fields; the rest stay NULL / 0.
 */
#ifndef AST_H
#define AST_H

#include "tokens.h"

#define MAX_DIMS 4      /* arrays may have up to 4 dimensions: a[2][3][4][5] */

/* The basic types of the language */
typedef enum {
    BT_ERROR = 0,       /* used after an error, so one mistake is reported only once */
    BT_INT,             /* পূর্ণসংখ্যা  int   */
    BT_FLOAT,           /* দশমিক       float */
    BT_CHAR             /* অক্ষর        char  */
} BaseType;

/* A full type: a basic type, plus array sizes if it is an array.
     পূর্ণসংখ্যা ক;          base = BT_INT,  ndims = 0
     পূর্ণসংখ্যা ক[১০];      base = BT_INT,  ndims = 1, dims = {10}
     অক্ষর নাম[৫][২০];     base = BT_CHAR, ndims = 2, dims = {5, 20}
   A size of -1 means "not written", as in  অক্ষর নাম[] = "রহিম";      */
typedef struct {
    BaseType base;
    int ndims;
    int dims[MAX_DIMS];
} Type;

typedef enum {
    /* statements */
    NODE_PROGRAM,     /* পূর্ণসংখ্যা প্রধান() { ... }:  body = the BLOCK            */
    NODE_BLOCK,       /* { ... }:              list = first item                    */
    NODE_DECL,        /* type a, b[৫] = {...};  type.base, list = DECLARATORs        */
    NODE_DECLARATOR,  /* one declared name:   text, type (with sizes), value = initial value */
    NODE_EXPR_STMT,   /* expression ;         left = expression (NULL for a lone ;) */
    NODE_PRINT,       /* দেখাও("...", a, b);  value = format STRING, list = values  */
    NODE_INPUT,       /* নাও("...", &a);      value = format STRING, list = values  */
    NODE_IF,          /* cond, body, else_body (may be NULL)                        */
    NODE_WHILE,       /* cond, body                                                 */
    NODE_DO,          /* body, cond                                                 */
    NODE_FOR,         /* init (a DECL or an expression), cond, update, body         */
    NODE_BREAK,       /* থামো                                                       */
    NODE_CONTINUE,    /* পরবর্তী                                                     */
    NODE_RETURN,      /* ফেরত value                                                 */

    /* expressions */
    NODE_INT,         /* text = "25"                                                */
    NODE_FLOAT,       /* text = "3.14"                                              */
    NODE_CHAR,        /* text = "'A'"                                               */
    NODE_STRING,      /* text = "\"...\""                                           */
    NODE_VAR,         /* text = variable name                                       */
    NODE_BINARY,      /* left op right                                              */
    NODE_UNARY,       /* op left    (- + ! ~ & and prefix ++ --)                    */
    NODE_POSTFIX,     /* left op    (postfix ++ --)                                 */
    NODE_ASSIGN,      /* left op right   (= += -= *= /= %=)                         */
    NODE_INDEX,       /* left[right]                                                */
    NODE_CAST,        /* (type) left                                                */
    NODE_TERNARY,     /* cond ? left : right                                        */
    NODE_INIT_LIST    /* { a, b, c } in a declaration: list = the values            */
} NodeKind;

struct Symbol;        /* defined in symbol_table.h */

typedef struct Node {
    NodeKind kind;
    int line;               /* source line, for error messages                  */
    char *text;             /* variable name, or a value exactly as written     */
    TokenType op;           /* the operator of operator nodes                   */
    Type type;              /* DECL / DECLARATOR / CAST: the written type.
                               expressions: the type found by semantic analysis */
    int parens;             /* 1 if the expression was written inside ( )       */
    struct Node *left;
    struct Node *right;
    struct Node *value;
    struct Node *cond;
    struct Node *body;
    struct Node *else_body;
    struct Node *init;
    struct Node *update;
    struct Node *list;      /* first item of a list                             */
    struct Node *next;      /* the next item in that list                       */
    struct Symbol *sym;     /* the variable this node uses (set in semantic analysis) */
} Node;

Node       *new_node(NodeKind kind, int line);
void        append_node(Node **list, Node *item);   /* add item to the end of a list */
char       *copy_string(const char *text);
Type        scalar_type(BaseType base);             /* a type that is not an array */
const char *base_name(BaseType base);               /* BT_INT -> "পূর্ণসংখ্যা" */
const char *c_base_name(BaseType base);             /* BT_INT -> "int"         */
void        describe_type(Type type, char *buffer); /* e.g. "পূর্ণসংখ্যা[10]"   */
const char *op_text(TokenType op);                  /* OP_PLUS -> "+"          */
void        ast_print(const Node *node, int depth);

#endif
