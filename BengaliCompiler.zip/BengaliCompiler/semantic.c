/*
 * semantic.c - PHASE 3: SEMANTIC ANALYSIS
 *
 * The parser only checks that the program is grammatically correct.
 * This phase checks that it MAKES SENSE, using C's rules. It walks the
 * syntax tree and:
 *
 *   - adds every declared variable to the symbol table
 *   - reports a variable declared twice in the same { } block
 *   - reports a variable used without being declared
 *   - works out the type of every expression and applies C's type rules
 *   - checks arrays: sizes, initial values, [ ] used on non-arrays,
 *     assigning to a whole array (not allowed in C)
 *   - checks that থামো / পরবর্তী are inside a loop
 *   - checks every দেখাও (printf) and নাও (scanf) format against its values:
 *     %d needs a whole number, %f a দশমিক, %s an অক্ষর array, and নাও needs
 *     &variable. In C these mistakes compile but give wrong output or crash.
 *
 * TYPE RULES (the same as C)
 *   - পূর্ণসংখ্যা, দশমিক and অক্ষর values can be mixed in arithmetic.
 *     The result is দশমিক if either side is দশমিক, otherwise পূর্ণসংখ্যা.
 *   - %  << >> & | ^ ~ need whole numbers (পূর্ণসংখ্যা or অক্ষর).
 *   - comparisons, && || ! give 1 (true) or 0 (false).
 *   - storing a দশমিক in a পূর্ণসংখ্যা is allowed, as in C, but the fraction is
 *     dropped, so a WARNING is shown.
 *   - an array as a whole can only be used with %s or [ ].
 *
 * WARNINGS do not stop the compilation; ERRORS do.
 *
 * After an error, the expression gets the type BT_ERROR. Any check that sees
 * BT_ERROR stays silent, so a single mistake produces a single message.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>
#include "semantic.h"
#include "symbol_table.h"

static int errors;
static int warnings;
static int loop_depth;      /* how many loops we are inside (for থামো / পরবর্তী) */

static void semantic_error(int line, const char *format, ...)
{
    va_list args;
    printf("Line %d: Semantic error: ", line);
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
    printf("\n");
    errors++;
}

static void semantic_warning(int line, const char *format, ...)
{
    va_list args;
    printf("Line %d: Warning: ", line);
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
    printf("\n");
    warnings++;
}

/* ------------------------------------------------------------------ */
/*  Small helpers                                                      */
/* ------------------------------------------------------------------ */

static Type error_type(void)        { return scalar_type(BT_ERROR); }
static int  is_error(Type type)     { return type.base == BT_ERROR; }
static int  is_integer(Type type)
{
    return type.ndims == 0 && (type.base == BT_INT || type.base == BT_CHAR);
}

/* C's "usual arithmetic conversion": দশমিক if either side is দশমিক */
static Type arithmetic_result(Type a, Type b)
{
    return scalar_type((a.base == BT_FLOAT || b.base == BT_FLOAT) ? BT_FLOAT : BT_INT);
}

static int is_lvalue(const Node *node)
{
    return node != NULL && (node->kind == NODE_VAR || node->kind == NODE_INDEX);
}

/* The variable name inside  ক  or  ক[i][j]  (for messages) */
static const char *root_name(const Node *node)
{
    while (node != NULL && node->kind == NODE_INDEX)
        node = node->left;
    return (node != NULL && node->kind == NODE_VAR) ? node->text : "this value";
}

static int is_literal_zero(const Node *node)
{
    return node != NULL && (node->kind == NODE_INT || node->kind == NODE_FLOAT) &&
           atof(node->text) == 0.0;
}

/* Does an int literal fit into a C int (at most 2147483647)? */
static int fits_in_int(const char *digits)
{
    size_t length;
    while (*digits == '0' && digits[1] != '\0')
        digits++;
    length = strlen(digits);
    if (length != 10)
        return length < 10;
    return strcmp(digits, "2147483647") <= 0;
}

/* Number of bytes a text in quotes needs, not counting the hidden '\0'.
   An escape like \n counts as 1 byte. A Bengali letter counts as 3. */
static int string_bytes(const char *text)
{
    int i, count = 0, length = (int) strlen(text);
    for (i = 1; i < length - 1; i++) {
        if (text[i] == '\\')
            i++;
        count++;
    }
    return count;
}

static int list_length(const Node *first)
{
    int count = 0;
    for (; first != NULL; first = first->next)
        count++;
    return count;
}

/* Does the expression use this variable? */
static int uses_symbol(const Node *node, const Symbol *symbol)
{
    const Node *item;
    if (node == NULL)
        return 0;
    if (node->kind == NODE_VAR && node->sym == symbol)
        return 1;
    if (uses_symbol(node->left, symbol) || uses_symbol(node->right, symbol) ||
        uses_symbol(node->cond, symbol))
        return 1;
    for (item = node->list; item != NULL; item = item->next)
        if (uses_symbol(item, symbol))
            return 1;
    return 0;
}

/* Warn when a দশমিক value is stored in a পূর্ণসংখ্যা or অক্ষর */
static void check_conversion(int line, Type target, Type value, const char *name)
{
    if (!is_error(value) && value.base == BT_FLOAT && target.base != BT_FLOAT)
        semantic_warning(line, "a দশমিক value is stored in the %s '%s', so the part after "
                               "the decimal point is dropped", base_name(target.base), name);
}

/* ------------------------------------------------------------------ */
/*  Expressions                                                        */
/* ------------------------------------------------------------------ */

static Type check_expression(Node *node);

/* The value must be a single value, not a whole array or a text in quotes. */
static int require_single_value(const Node *node, Type type)
{
    if (is_error(type))
        return 0;
    if (type.ndims == 0)
        return 1;
    if (node->kind == NODE_STRING)
        semantic_error(node->line, "text in quotes can only be used as the format of "
                                   "দেখাও / নাও, with %%s, or to fill an অক্ষর array");
    else
        semantic_error(node->line, "'%s' is an array; use one element, like %s[০]",
                       root_name(node), root_name(node));
    return 0;
}

/* Check an expression that must be a single value */
static Type check_value(Node *node)
{
    Type type = check_expression(node);
    return require_single_value(node, type) ? type : error_type();
}

/* The target of = += ++ -- &: a variable or an array element */
static Type check_target(Node *node, const char *op, int is_assignment)
{
    Type type;
    if (node == NULL)
        return error_type();
    type = check_expression(node);
    if (is_error(type))
        return type;

    if (!is_lvalue(node)) {
        if (is_assignment)
            semantic_error(node->line, "the left side of '%s' must be a variable or an array element", op);
        else
            semantic_error(node->line, "'%s' needs a variable or an array element", op);
        return error_type();
    }
    if (type.ndims > 0) {
        if (is_assignment)
            semantic_error(node->line, "cannot assign to the whole array '%s' (C does not allow it); "
                                       "assign one element at a time", root_name(node));
        else
            semantic_error(node->line, "'%s' cannot be used on the whole array '%s'",
                           op, root_name(node));
        return error_type();
    }
    return type;
}

static Type check_index(Node *node)
{
    Type array = check_expression(node->left);
    Type index = check_expression(node->right);
    Type result;
    int d;

    if (require_single_value(node->right, index) && index.base == BT_FLOAT)
        semantic_error(node->line, "an array index must be a whole number, but this one is দশমিক");

    if (is_error(array))
        return error_type();
    if (array.ndims == 0) {
        semantic_error(node->line, "'%s' is not an array, so it cannot be used with [ ]",
                       root_name(node->left));
        return error_type();
    }

    /* an index written as a number can be checked now */
    if (node->right != NULL && node->right->kind == NODE_INT && array.dims[0] > 0 &&
        atol(node->right->text) >= array.dims[0])
        semantic_warning(node->line, "index %s is outside the array '%s' (its indexes go "
                                     "from 0 to %d)", node->right->text,
                         root_name(node->left), array.dims[0] - 1);
    if (node->right != NULL && node->right->kind == NODE_UNARY && node->right->op == OP_MINUS &&
        node->right->left != NULL && node->right->left->kind == NODE_INT)
        semantic_warning(node->line, "a negative index is outside the array '%s'",
                         root_name(node->left));

    /* ক[i] has the type of ক without its first size */
    result = array;
    result.ndims--;
    for (d = 0; d < result.ndims; d++)
        result.dims[d] = array.dims[d + 1];
    return result;
}

static Type check_unary(Node *node)
{
    Type type;
    switch (node->op) {
    case OP_AMP:
        check_expression(node->left);
        semantic_error(node->line, "& (address of) can only be used inside নাও(...), "
                                   "like নাও(\"%%d\", &ক);");
        return error_type();

    case OP_INC:
    case OP_DEC:
        return check_target(node->left, op_text(node->op), 0);

    case OP_MINUS:
    case OP_PLUS:
        type = check_value(node->left);
        if (is_error(type))
            return type;
        return scalar_type(type.base == BT_FLOAT ? BT_FLOAT : BT_INT);

    case OP_NOT:
        type = check_value(node->left);
        return is_error(type) ? type : scalar_type(BT_INT);

    case OP_TILDE:
        type = check_value(node->left);
        if (is_error(type))
            return type;
        if (!is_integer(type)) {
            semantic_error(node->line, "'~' needs a whole number, but got দশমিক");
            return error_type();
        }
        return scalar_type(BT_INT);

    default:
        return error_type();
    }
}

static Type check_binary(Node *node)
{
    Type left, right;
    const char *op = op_text(node->op);

    if (node->op == COMMA) {            /* a, b : the value is b */
        check_expression(node->left);
        return check_expression(node->right);
    }

    left  = check_value(node->left);
    right = check_value(node->right);
    if (is_error(left) || is_error(right))
        return error_type();

    switch (node->op) {
    case OP_PLUS: case OP_MINUS: case OP_MUL: case OP_DIV:
        if (node->op == OP_DIV && is_integer(left) && is_integer(right) &&
            is_literal_zero(node->right))
            semantic_warning(node->line, "division by zero");
        return arithmetic_result(left, right);

    case OP_MOD: case OP_SHL: case OP_SHR: case OP_AMP: case OP_BIT_OR: case OP_XOR:
        if (!is_integer(left) || !is_integer(right)) {
            semantic_error(node->line, "'%s' needs whole numbers (পূর্ণসংখ্যা or অক্ষর), "
                                       "but got %s and %s", op,
                           base_name(left.base), base_name(right.base));
            return error_type();
        }
        if (node->op == OP_MOD && is_literal_zero(node->right))
            semantic_warning(node->line, "division by zero (in '%%')");
        return scalar_type(BT_INT);

    default:            /* comparisons, && and || */
        return scalar_type(BT_INT);
    }
}

static Type check_assignment(Node *node)
{
    const char *op = op_text(node->op);
    Type target = check_target(node->left, op, 1);
    Type value;

    if (is_error(target)) {             /* already reported: only look for other  */
        check_expression(node->right);  /* mistakes (e.g. undeclared variables)   */
        return error_type();
    }
    value = check_value(node->right);
    if (is_error(value))
        return error_type();

    if (node->op == OP_MOD_ASSIGN && (!is_integer(target) || !is_integer(value))) {
        semantic_error(node->line, "'%%=' needs whole numbers (পূর্ণসংখ্যা or অক্ষর)");
        return error_type();
    }
    check_conversion(node->line, target, value, root_name(node->left));
    return target;
}

static Type check_expression(Node *node)
{
    Type type = error_type();
    Symbol *symbol;

    if (node == NULL)
        return error_type();

    switch (node->kind) {
    case NODE_INT:
        if (!fits_in_int(node->text))
            semantic_error(node->line, "the number %s is too big for a পূর্ণসংখ্যা "
                                       "(the largest is 2147483647)", node->text);
        type = scalar_type(BT_INT);
        break;

    case NODE_FLOAT:
        type = scalar_type(BT_FLOAT);
        break;

    case NODE_CHAR:
        type = scalar_type(BT_CHAR);
        break;

    case NODE_STRING:                   /* "..." is an অক্ষর array */
        type = scalar_type(BT_CHAR);
        type.ndims = 1;
        type.dims[0] = string_bytes(node->text) + 1;
        break;

    case NODE_VAR:
        symbol = st_find(node->text);
        if (symbol == NULL) {
            semantic_error(node->line, "variable '%s' is used but was never declared", node->text);
        } else {
            node->sym = symbol;
            type = symbol->type;
        }
        break;

    case NODE_INDEX:
        type = check_index(node);
        break;

    case NODE_UNARY:
        type = check_unary(node);
        break;

    case NODE_POSTFIX:
        type = check_target(node->left, op_text(node->op), 0);
        break;

    case NODE_BINARY:
        type = check_binary(node);
        break;

    case NODE_ASSIGN:
        type = check_assignment(node);
        break;

    case NODE_CAST:
        if (!is_error(check_value(node->left)))
            type = node->type;
        break;

    case NODE_TERNARY: {
        Type cond  = check_value(node->cond);
        Type left  = check_value(node->left);
        Type right = check_value(node->right);
        if (!is_error(cond) && !is_error(left) && !is_error(right))
            type = arithmetic_result(left, right);
        break;
    }

    case NODE_INIT_LIST:
        semantic_error(node->line, "a { } list can only give the first values of an array");
        break;

    default:
        break;
    }

    if (node->kind != NODE_CAST)        /* a cast node keeps its written type */
        node->type = type;
    return type;
}

/* ------------------------------------------------------------------ */
/*  দেখাও (printf) and নাও (scanf) formats                              */
/* ------------------------------------------------------------------ */

enum Expected {
    WANT_WHOLE,        /* printf %d %i %u %x %X %o %c, and the * in %*d */
    WANT_DECIMAL,      /* printf %f %e %g                               */
    WANT_TEXT,         /* %s: an অক্ষর array                             */
    WANT_ADDR_INT,     /* scanf %d: &পূর্ণসংখ্যা                          */
    WANT_ADDR_FLOAT,   /* scanf %f: &দশমিক                               */
    WANT_ADDR_CHAR,    /* scanf %c: &অক্ষর                                */
    WANT_NOTHING       /* the % code itself was wrong (already reported)  */
};

/* Looks for mistakes such as undeclared variables in a value whose
   % code was wrong, without reporting the & of নাও as an error. */
static void skip_argument(Node *arg)
{
    if (arg->kind == NODE_UNARY && arg->op == OP_AMP)
        check_expression(arg->left);
    else
        check_expression(arg);
}

static const char *format_for(BaseType base)
{
    return base == BT_FLOAT ? "%f" : base == BT_CHAR ? "%c" : "%d";
}

static void check_argument(Node *arg, enum Expected want, const char *code,
                           int number, const char *keyword)
{
    Type type;
    BaseType wanted_base;

    if (want == WANT_ADDR_INT || want == WANT_ADDR_FLOAT || want == WANT_ADDR_CHAR) {
        wanted_base = want == WANT_ADDR_INT ? BT_INT : want == WANT_ADDR_FLOAT ? BT_FLOAT : BT_CHAR;

        if (arg->kind == NODE_UNARY && arg->op == OP_AMP) {
            type = check_target(arg->left, "&", 0);
            if (is_error(type))
                return;
            if (type.base != wanted_base)
                semantic_error(arg->line, "%s: %s needs the address of a %s variable, but '%s' is %s "
                                          "(use %s for it)", keyword, code, base_name(wanted_base),
                               root_name(arg->left), base_name(type.base), format_for(type.base));
            return;
        }

        type = check_expression(arg);
        if (is_error(type))
            return;
        if (is_lvalue(arg) && type.ndims == 0)
            semantic_error(arg->line, "%s: %s needs the address of the variable: write &%s "
                                      "(without & the program crashes)", keyword, code,
                           root_name(arg));
        else
            semantic_error(arg->line, "%s: %s needs the address of a %s variable, like &ক",
                           keyword, code, base_name(wanted_base));
        return;
    }

    if (want == WANT_TEXT) {
        if (arg->kind == NODE_UNARY && arg->op == OP_AMP) {
            type = check_expression(arg->left);
            if (!is_error(type))
                semantic_error(arg->line, "%s: for %s write the array name without &: %s",
                               keyword, code, root_name(arg->left));
            return;
        }
        type = check_expression(arg);
        if (!is_error(type) && !(type.base == BT_CHAR && type.ndims == 1)) {
            char described[100];
            describe_type(type, described);
            semantic_error(arg->line, "%s: %s needs an অক্ষর array (text), but value %d is %s",
                           keyword, code, number, described);
        }
        return;
    }

    /* WANT_WHOLE or WANT_DECIMAL */
    type = check_expression(arg);
    if (is_error(type))
        return;
    if (type.ndims > 0) {
        semantic_error(arg->line, "%s: %s needs a single value, but value %d is %s",
                       keyword, code, number,
                       arg->kind == NODE_STRING ? "a text in quotes (use %s)" : "an array");
        return;
    }
    if (want == WANT_WHOLE && type.base == BT_FLOAT)
        semantic_error(arg->line, "%s: %s needs a whole number, but value %d is দশমিক "
                                  "(use %%f, or convert it with (পূর্ণসংখ্যা))", keyword, code, number);
    if (want == WANT_DECIMAL && type.base != BT_FLOAT)
        semantic_error(arg->line, "%s: %s needs a দশমিক value, but value %d is %s "
                                  "(use %s, or convert it with (দশমিক))", keyword, code, number,
                       base_name(type.base), format_for(type.base));
}

static void check_format(Node *node, int is_input)
{
    const char *keyword = is_input ? "নাও" : "দেখাও";
    const char *format;
    Node *arg = node->list;
    int i, length, number = 1, missing_reported = 0;

    if (node->value == NULL)            /* the parser already reported a missing format */
        return;
    format = node->value->text;
    length = (int) strlen(format);

    for (i = 1; i < length - 1; i++) {
        char code[40];
        int start, suppress = 0, long_size = 0;
        char conversion;
        enum Expected want;

        if (format[i] == '\\') {        /* skip escapes like \n */
            i++;
            continue;
        }
        if (format[i] != '%')
            continue;

        start = i++;
        if (format[i] == '%')           /* %% prints a % sign */
            continue;

        if (is_input && format[i] == '*') {         /* scanf %*d: read and throw away */
            suppress = 1;
            i++;
        }
        if (!is_input)
            while (format[i] != '\0' && strchr("-+ #0", format[i]) != NULL)
                i++;                                /* flags */
        if (!is_input && format[i] == '*') {        /* width given as a value */
            if (arg != NULL) {
                check_argument(arg, WANT_WHOLE, "the * in the format", number++, keyword);
                arg = arg->next;
            }
            i++;
        }
        while (isdigit((unsigned char) format[i]))  /* width */
            i++;
        if (!is_input && format[i] == '.') {        /* precision */
            i++;
            if (format[i] == '*') {
                if (arg != NULL) {
                    check_argument(arg, WANT_WHOLE, "the .* in the format", number++, keyword);
                    arg = arg->next;
                }
                i++;
            }
            while (isdigit((unsigned char) format[i]))
                i++;
        }
        if (format[i] == 'l') {
            long_size = 1;
            i++;
        }
        if (format[i] != '\0' && strchr("lhLjzt", format[i]) != NULL) {
            semantic_error(node->line, "%s: size letters like '%c' are not supported "
                                       "(there are no long or short types)", keyword, format[i]);
            while (format[i] != '\0' && strchr("lhLjzt", format[i]) != NULL)
                i++;
            long_size = 0;
        }

        conversion = format[i];
        if (i >= length - 1) {
            semantic_error(node->line, "%s: the format ends with an unfinished %% code "
                                       "(write %%%% to show a %% sign)", keyword);
            break;
        }
        snprintf(code, sizeof code, "%.*s", i - start + 1, format + start);

        if ((unsigned char) conversion >= 0x80) {
            semantic_error(node->line, "%s: a %% code must use English letters and digits, "
                                       "like %%5d (not %%৫d)", keyword);
            want = WANT_NOTHING;
        } else if (strchr("diuxXoc", conversion) != NULL) {
            if (long_size) {
                semantic_error(node->line, "%s: %s is for long numbers, which this language "
                                           "does not have; use %%%c", keyword, code, conversion);
                want = WANT_NOTHING;
            } else {
                want = !is_input ? WANT_WHOLE : (conversion == 'c' ? WANT_ADDR_CHAR : WANT_ADDR_INT);
            }
        } else if (strchr("fFeEgG", conversion) != NULL) {
            if (is_input && long_size) {
                semantic_error(node->line, "%s: %s reads a double; for a দশমিক (float) "
                                           "variable use %%%c", keyword, code, conversion);
                want = WANT_NOTHING;
            } else {
                want = is_input ? WANT_ADDR_FLOAT : WANT_DECIMAL;
            }
        } else if (conversion == 's') {
            want = WANT_TEXT;
        } else {
            semantic_error(node->line, "%s: unknown format code %s (use %%d %%i %%u %%x %%o "
                                       "%%c %%f %%e %%g %%s or %%%%)", keyword, code);
            want = WANT_NOTHING;
        }

        if (suppress)
            continue;
        if (arg == NULL) {
            if (!missing_reported && want != WANT_NOTHING)
                semantic_error(node->line, "%s: the format has %s, but no value is given for it",
                               keyword, code);
            missing_reported = 1;
            continue;
        }
        /* A wrong % code was already reported: its value is still paired
           with it, so the next values line up with the next codes. */
        if (want == WANT_NOTHING)
            skip_argument(arg);
        else
            check_argument(arg, want, code, number, keyword);
        number++;
        arg = arg->next;
    }

    if (arg != NULL) {
        semantic_error(node->line, "%s: %d more value(s) than %% codes in the format",
                       keyword, list_length(arg));
        for (; arg != NULL; arg = arg->next)
            skip_argument(arg);
    }
}

/* ------------------------------------------------------------------ */
/*  Declarations                                                       */
/* ------------------------------------------------------------------ */

/* Checks { ... } or "..." given to an array. type->dims[level] is the size
   at this level; if it was left empty (-1) it is filled in from the values. */
static void check_array_values(Node *value, Type *type, int level, const char *name)
{
    int is_last = (level == type->ndims - 1);
    int size = type->dims[level];
    int count;
    Node *item;

    if (value->kind == NODE_STRING && type->base == BT_CHAR && is_last) {
        int needed = string_bytes(value->text) + 1;
        if (size < 0)
            type->dims[level] = needed;
        else if (needed > size)
            semantic_error(value->line, "the text needs %d bytes (including the hidden '\\0' at "
                                        "the end), but '%s' has room for %d. Each Bengali letter "
                                        "takes 3 bytes", needed, name, size);
        return;
    }

    if (value->kind != NODE_INIT_LIST) {
        if (type->base == BT_CHAR && is_last)
            semantic_error(value->line, "'%s' is an array: fill it with \"text\" or a { } list", name);
        else
            semantic_error(value->line, "'%s' is an array: fill it with a { } list, like {১, ২, ৩}", name);
        return;
    }

    count = list_length(value->list);
    for (item = value->list; item != NULL; item = item->next) {
        if (is_last) {
            if (item->kind == NODE_INIT_LIST) {
                semantic_error(item->line, "too many { } levels in the values of '%s'", name);
            } else {
                Type item_type = check_value(item);
                check_conversion(item->line, *type, item_type, name);
            }
        } else if (item->kind == NODE_INIT_LIST ||
                   (item->kind == NODE_STRING && type->base == BT_CHAR && level + 1 == type->ndims - 1)) {
            check_array_values(item, type, level + 1, name);
        } else {
            semantic_error(item->line, "each row of '%s' needs its own { }, like {{১, ২}, {৩, ৪}}", name);
        }
    }

    if (size < 0)
        type->dims[level] = count;
    else if (count > size)
        semantic_error(value->line, "too many values for '%s': %d given, but it has room for %d",
                       name, count, size);
}

static void check_declarator(Node *node)
{
    Type type = node->type;
    Symbol *old;
    long total = 1;
    int d, sizes_ok = 1;

    for (d = 0; d < type.ndims; d++) {
        if (type.dims[d] == 0) {
            semantic_error(node->line, "the size of array '%s' must be at least 1", node->text);
            sizes_ok = 0;
        } else if (type.dims[d] < 0 && d > 0) {
            semantic_error(node->line, "only the first size of array '%s' can be left empty", node->text);
            sizes_ok = 0;
        } else if (type.dims[d] >= 1000000000) {
            semantic_error(node->line, "array '%s' is too big", node->text);
            sizes_ok = 0;
        }
    }
    if (type.ndims > 0 && type.dims[0] < 0 && node->value == NULL) {
        semantic_error(node->line, "array '%s' needs a size, like %s[১০]", node->text, node->text);
        sizes_ok = 0;
    }

    old = st_find_in_current_scope(node->text);
    if (old != NULL) {
        semantic_error(node->line, "variable '%s' is already declared on line %d", node->text, old->line);
        if (node->value != NULL && node->value->kind != NODE_INIT_LIST && type.ndims == 0)
            check_expression(node->value);
        return;
    }

    /* As in C, the new variable exists from here on, even inside its own first value. */
    node->sym = st_add(node->text, type, node->line);

    if (node->value != NULL) {
        if (type.ndims == 0) {
            if (node->value->kind == NODE_INIT_LIST) {
                semantic_error(node->line, "'%s' is a single value; give it one value, not a { } list",
                               node->text);
            } else {
                Type value = check_value(node->value);
                check_conversion(node->line, type, value, node->text);
            }
        } else if (sizes_ok) {
            check_array_values(node->value, &node->sym->type, 0, node->text);
        }
        if (uses_symbol(node->value, node->sym))
            semantic_warning(node->line, "'%s' is used in its own first value, where it has no "
                                         "value yet", node->text);
    }

    /* A big array inside a function can be larger than the stack (about 1 MB on Windows) */
    if (sizes_ok && type.ndims > 0) {
        for (d = 0; d < node->sym->type.ndims; d++)
            total *= node->sym->type.dims[d];
        if (total * (type.base == BT_CHAR ? 1 : 4) > 1000000L)
            semantic_warning(node->line, "array '%s' is very big (%ld values); the program may crash "
                                         "when it starts", node->text, total);
    }
}

/* ------------------------------------------------------------------ */
/*  Statements                                                         */
/* ------------------------------------------------------------------ */

static void check_statement(Node *node);

static int has_effect(const Node *node)
{
    if (node == NULL)
        return 0;
    if (node->kind == NODE_BINARY && node->op == COMMA)
        return has_effect(node->left) || has_effect(node->right);
    return node->kind == NODE_ASSIGN || node->kind == NODE_POSTFIX ||
           (node->kind == NODE_UNARY && (node->op == OP_INC || node->op == OP_DEC));
}

static void check_condition(Node *cond, const char *keyword)
{
    check_value(cond);
    if (cond != NULL && cond->kind == NODE_ASSIGN && cond->op == OP_ASSIGN && !cond->parens)
        semantic_warning(cond->line, "'=' in the condition of %s stores a value; to compare "
                                     "two values use '=='", keyword);
}

static void check_statement(Node *node)
{
    Node *item;
    Type type;

    if (node == NULL)
        return;

    switch (node->kind) {
    case NODE_PROGRAM:
        check_statement(node->body);
        break;

    case NODE_BLOCK:
        st_enter_scope();
        for (item = node->list; item != NULL; item = item->next)
            check_statement(item);
        st_exit_scope();
        break;

    case NODE_DECL:
        for (item = node->list; item != NULL; item = item->next)
            check_declarator(item);
        break;

    case NODE_EXPR_STMT:
        if (node->left == NULL)
            break;
        type = check_expression(node->left);
        if (!is_error(type) && !has_effect(node->left)) {
            if (node->left->kind == NODE_BINARY && node->left->op == OP_EQ)
                semantic_warning(node->line, "this '==' compares but stores nothing; to store a "
                                             "value use '='");
            else
                semantic_warning(node->line, "this statement has no effect");
        }
        break;

    case NODE_PRINT:
        check_format(node, 0);
        break;

    case NODE_INPUT:
        check_format(node, 1);
        break;

    case NODE_IF:
        check_condition(node->cond, "যদি");
        check_statement(node->body);
        check_statement(node->else_body);
        break;

    case NODE_WHILE:
        check_condition(node->cond, "যতক্ষণ");
        loop_depth++;
        check_statement(node->body);
        loop_depth--;
        break;

    case NODE_DO:
        loop_depth++;
        check_statement(node->body);
        loop_depth--;
        check_condition(node->cond, "করো ... যতক্ষণ");
        break;

    case NODE_FOR:
        st_enter_scope();                 /* a variable declared in the first part */
        if (node->init != NULL) {         /* belongs to the loop only, as in C     */
            if (node->init->kind == NODE_DECL)
                check_statement(node->init);
            else
                check_expression(node->init);
        }
        if (node->cond != NULL)
            check_condition(node->cond, "গণনার জন্য");
        if (node->update != NULL) {
            type = check_expression(node->update);
            if (!is_error(type) && !has_effect(node->update))
                semantic_warning(node->update->line, "the third part of গণনার জন্য has no effect "
                                                     "(did you mean i++ or i = i + 1?)");
        }
        loop_depth++;
        check_statement(node->body);
        loop_depth--;
        st_exit_scope();
        break;

    case NODE_BREAK:
    case NODE_CONTINUE:
        if (loop_depth == 0)
            semantic_error(node->line, "%s can only be used inside a loop "
                                       "(যতক্ষণ, গণনার জন্য or করো)",
                           node->kind == NODE_BREAK ? "থামো" : "পরবর্তী");
        break;

    case NODE_RETURN:
        type = check_value(node->value);
        if (!is_error(type) && type.base == BT_FLOAT)
            semantic_warning(node->line, "প্রধান() returns a পূর্ণসংখ্যা, so the part after the "
                                         "decimal point is dropped");
        break;

    default:
        break;
    }
}

int semantic_check(Node *program)
{
    errors = 0;
    warnings = 0;
    loop_depth = 0;
    check_statement(program);
    return errors;
}

int semantic_warning_count(void)
{
    return warnings;
}
