/*
 * semantic.h - PHASE 3: SEMANTIC ANALYSIS
 */
#ifndef SEMANTIC_H
#define SEMANTIC_H

#include "ast.h"

/* Checks the meaning of the program and fills in the symbol table.
   Returns the number of semantic errors found. */
int semantic_check(Node *program);

/* Number of warnings found by the last semantic_check() */
int semantic_warning_count(void);

#endif
