/*
 * tac.h - INTERMEDIATE CODE: three-address code (shown with --tac)
 */
#ifndef TAC_H
#define TAC_H

#include "ast.h"

void tac_print(const Node *program);

#endif
