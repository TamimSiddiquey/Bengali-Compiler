@echo off
rem ================================================================
rem  run_tests.bat - compiles and runs every program in tests\
rem    01 to 12 : correct programs, they must compile and run
rem    w1       : correct program with warnings, it must still run
rem    e1 to e4 : programs with mistakes, they must be rejected
rem  Programs that read input get it from tests\input.txt
rem  To save the results:   run_tests > test_results.txt
rem ================================================================

if not exist bnc.exe (
    echo bnc.exe not found. Run build.bat first.
    goto end
)

for %%f in (tests\*.bn) do (
    echo.
    echo ############################################################
    echo  TEST: %%f
    echo ############################################################
    bnc.exe %%f < tests\input.txt
)

:end
