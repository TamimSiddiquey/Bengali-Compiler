@echo off
rem ================================================================
rem  build.bat - builds the Bengali compiler (bnc.exe)
rem  Usage: build
rem ================================================================

echo [1/2] flex project.l
flex project.l
if errorlevel 1 goto failed

echo [2/2] gcc ... -o bnc.exe
gcc lex.yy.c parser.c ast.c symbol_table.c semantic.c tac.c code_generator.c main.c -o bnc.exe
if errorlevel 1 goto failed

echo.
echo Build successful: bnc.exe
echo Try:   bnc project.bn
echo        bnc project.bn --all
goto end

:failed
echo.
echo Build FAILED. Read the messages above.

:end
